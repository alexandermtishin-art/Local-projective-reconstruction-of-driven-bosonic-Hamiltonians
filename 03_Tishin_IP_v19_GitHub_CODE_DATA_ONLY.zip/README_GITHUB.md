# Endpoint reconstruction — reproducibility archive

This repository contains **code and data only**. It does not contain the main manuscript, supplementary manuscript, submission letters, or internal reviews.

Source: code/data from the v19 preparation package. See `endpoint_reconstruction/README.md` for execution and provenance instructions.
