"""Projective restricted-class rank checks and deterministic acquisition controls."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json,math
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent
# N=4, E0 derivatives fixed, independent values/first/second derivatives elsewhere.
N=4;order=12;params=[(kind,j,q) for q in range(3) for kind,js in [('E',range(1,N)),('g',range(N-1))] for j in js]
def data_matrices(static=False):
 H=[x[:N,:N].copy() for x in m.H];
 if static:H[1][:]=0;H[2][:]=0
 C=np.zeros((order+1,N,19),complex);C[0,0,0]=1
 for k in range(order):
  term=sum(H[q]@C[k-q] for q in range(min(k,2)+1))
  for col,(kind,j,q) in enumerate(params,1):
   if k<q:continue
   if kind=='E':term[j,col]+=C[k-q,j,0]/math.factorial(q)
   else:term[j,col]+=C[k-q,j+1,0]/math.factorial(q);term[j+1,col]+=C[k-q,j,0]/math.factorial(q)
  C[k+1]=-1j*term/(k+1)
 Z=np.zeros_like(C)
 for n in range(1,N):
  for k in range(order+1):
   num=C[k,n].copy()
   for j in range(1,k+1):
    num[0]-=C[j,0,0]*Z[k-j,n,0]
    num[1:]-=C[j,0,0]*Z[k-j,n,1:]+C[j,0,1:]*Z[k-j,n,0]
   # c0(0)=1 and its parameter derivatives are zero.
   Z[k,n]=num
 P=np.zeros((order+1,18))
 for k in range(order+1):
  for j in range(k+1):P[k]+=2*np.real(C[j,0,0].conjugate()*C[k-j,0,1:])
 return {'z1':np.vstack([Z[1:,1,1:].real,Z[1:,1,1:].imag]),'p0':P[1:],'z1_z2':np.vstack([Z[1:,1:3,1:].real.reshape(-1,18),Z[1:,1:3,1:].imag.reshape(-1,18)])}
def rank(A,idx):
 a=A[:,idx];norm=np.linalg.norm(a,axis=0);nz=norm>0;aa=np.zeros_like(a);aa[:,nz]=a[:,nz]/norm[nz];s=np.linalg.svd(aa,compute_uv=False);return {'rank_relative_1e12':int(sum(s>s[0]*1e-12)),'columns':len(idx),'smallest_normalized_singular':float(s[-1]),'largest_normalized_singular':float(s[0])}
idx0=list(range(6));idxall=list(range(18));ranks={}
static=data_matrices(True);quadratic=data_matrices(False)
for obs,A in quadratic.items():ranks[obs]={'static':rank(static[obs],idx0),'quadratic':rank(A,idxall)}
# Deterministic fits use only degrees n,n+1,n+2 and the same endpoint formulas.
x=np.linspace(.1,1,61);T=.24;ts=T*x
h=lambda t:m.H[0]+m.H[1]*t+m.H[2]*t*t
def estimate(z):
 A=[1];RR=[0]
 for n in range(1,4):
  co=np.linalg.lstsq(x[:,None]**np.arange(n,n+3),z[:,n],rcond=None)[0];A.append(math.factorial(n)*co[0]/T**n);RR.append((n+1)*co[1]/(T*co[0]))
 return {'g2':float(abs(A[3]/A[2])),'E3_minus_E0':float(-(RR[3]-RR[2]).imag),'lograte_g2':float((RR[3]-RR[2]).real/3)}
def pure(ramp=None):
 def rhs(t,c):
  hh=h(t).copy()
  if ramp:
   for j in range(5):hh[j,j+1]*=1-np.exp(-t/ramp);hh[j+1,j]=hh[j,j+1]
  return -1j*hh@c
 c0=np.zeros(6,complex);c0[0]=1;sol=solve_ivp(rhs,(0,T),c0,t_eval=ts,method='DOP853',rtol=1e-12,atol=1e-14);return (sol.y/sol.y[0]).T
z=pure();rows=[{'model':'ideal_noiseless','estimate':estimate(z)}]
for a in [1e-6,1e-5,1e-3]:zz=z.copy();zz[:,1:4]+=a;rows.append({'model':'additive_real_ratio_offset','offset':a,'estimate':estimate(zz)})
for tau in [.002]:rows.append({'model':'coupling_only_ramp','tau_r':tau,'maximum_fractional_coupling_change_in_window':float(np.exp(-ts[0]/tau)),'estimate':estimate(pure(tau))})
# Physical oscillator thermal state, diagonal geometric number distribution.
for nb in [.01]:
 Nf=12;rho0=np.diag([(nb/(1+nb))**j/(1+nb) for j in range(Nf)]).astype(complex);rho0/=np.trace(rho0)
 def rhs(t,y):
  hh=np.zeros((Nf,Nf),complex);hh[::2,::2]=h(t);rr=y.reshape(Nf,Nf);return (-1j*(hh@rr-rr@hh)).ravel()
 sol=solve_ivp(rhs,(0,T),rho0.ravel(),t_eval=ts,method='DOP853',rtol=1e-12,atol=1e-14);rho=sol.y.T.reshape(61,Nf,Nf);zz=rho[:,::2,0]/rho[:,0,0,None];rows.append({'model':'geometric_thermal_Fock_preparation','nbar':nb,'estimate':estimate(zz)})
rho0=np.diag([.99,.01,0,0,0,0]).astype(complex)
def mixed_rhs(t,y):
 hh=h(t);rr=y.reshape(6,6);return (-1j*(hh@rr-rr@hh)).ravel()
sol=solve_ivp(mixed_rhs,(0,T),rho0.ravel(),t_eval=ts,method='DOP853',rtol=1e-12,atol=1e-14);rho=sol.y.T.reshape(61,6,6);zz=rho[:,:,0]/rho[:,0,0,None];rows.append({'model':'incoherent_site1_population','population':.01,'estimate':estimate(zz)})
out={'rank':ranks,'rank_scope':'one N=4 fixed-basis example; E0 time law known; local differential rank, not global or unrestricted identifiability','systematics':rows,'units':'hbar=1; T=.24; 61 times [.024,.24]; no noise; estimator supplied onset orders, not H law'}
_output_path(R / 'access_and_systematics.json').write_text(json.dumps(_record_environment(out),indent=2));print(json.dumps(_record_environment(out),indent=2))
