"""Independent checks of gap constants, partial access and equal-copy Fisher designs.
No experimental data or fitted success probabilities are produced.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json, math
from pathlib import Path
import numpy as np
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent
u=np.array([(7-math.sqrt(13))/2,(7+math.sqrt(13))/2]);K2=float(max(abs(np.exp(1-u)*(u**4-3*u**3))))
H0=m.H[0];ev=np.linalg.eigvalsh(H0);B=float((ev[-1]-ev[0])/2);L=float(np.linalg.norm(m.H[1],2)+.24*np.linalg.norm(2*m.H[2],2));delta=min(.5,L*.024/(K2*B));theta=float(m.E[3]-m.E[0]);floor=delta*abs(theta)/2
out={'gap':{'eta_prime_max':1,'eta_prime_min':-5*math.exp(-2),'eta_second_max':K2,'spectral_half_width':B,'L_sufficient_on_0_to_0p24' :L,'tau':.024,'theta':theta,'delta':delta,'absolute_error_floor':floor}}
Cs={k:m.series(k) for k in [0,2]}
def v(k,t):return m.eval_series(Cs[k],t)
def gaussian(start,stop,depth):
 rows=[]
 for t in np.linspace(start,stop,61):
  a=v(0,t);dz=(a[1:depth+1,1:]*a[0,0]-a[1:depth+1,0,None]*a[0,1:])/a[0,0]**2;rows.extend([dz.real,dz.imag])
 return np.vstack(rows)
def scale(J,b):
 norm=np.linalg.norm(J,axis=0);U,s,Vh=np.linalg.svd(J/norm,full_matrices=False);return float(np.linalg.norm((Vh@(b/norm))/s)),float(s[-1])
def sampling(start,stop,design):
 settings=sum(1+2*len(ns) for k,ns in design)
 J=np.vstack([m.rows(v(k,t),k,ns) for k,ns in design for t in np.linspace(start,stop,61)])/np.sqrt(settings*61)
 return J,settings
b=np.zeros(24);b[m.TARGET]=1
out['gaussian']=[]
for start,stop,depth in [(.024,.24,3),(.024,.24,4),(.192,.408,4),(.392,.608,4),(.3,.516,4),(.5,.716,4)]:
 J=gaussian(start,stop,depth);sd,s=scale(J,b);fixed=1/np.linalg.norm(J[:,m.TARGET]);center=(start+stop)/2;bt=np.zeros(24)
 for q in range(3):bt[m.PARAMS.index(('E',3,q))]=center**q/math.factorial(q)
 instant_sd,_=scale(J,bt)
 out['gaussian'].append({'instantaneous_target_time':center,'instantaneous_energy_sd_per_sigma':instant_sd,'start':start,'stop':stop,'depth':depth,'efficient_sd_per_sigma':sd,'inflation':sd/fixed,'smallest_normalized_singular':s})
out['multinomial']=[]
for start,stop,design,name in [(.024,.24,[(0,[1,2,3])],'endpoint3'),(.024,.24,[(0,[1,2,3,4])],'endpoint4'),(.192,.408,[(0,[1,2,3,4])],'later_center03'),(.392,.608,[(0,[1,2,3,4])],'later_center05'),(.024,.24,[(0,[1]),(2,[1,3])],'two_preparations')]:
 J,sn=sampling(start,stop,design);targets={}
 for target in ['E3(0)-E0(0)','g2(0)','gdot2(0)/g2(0)']:
  bb=np.zeros(24)
  if target.startswith('E'):bb[m.TARGET]=1
  elif target=='g2(0)':bb[m.PARAMS.index(('g',2,0))]=1
  else:bb[m.PARAMS.index(('g',2,0))]=-m.GD[2]/m.G[2]**2;bb[m.PARAMS.index(('g',2,1))]=1/m.G[2]
  ss,sv=scale(J,bb);targets[target]={'sd_times_sqrt_total_copies':ss,'sd_at_B_427e12':ss/np.sqrt(4.27e12)}
 bt=np.zeros(24);center=(start+stop)/2
 for q in range(3):bt[m.PARAMS.index(('E',3,q))]=center**q/math.factorial(q)
 ss,_=scale(J,bt);
 if name.startswith('later_'):targets['E3(center)-E0(center)']={'time':center,'sd_at_B_427e12':ss/np.sqrt(4.27e12)}
 out['multinomial'].append({'design':name,'start':start,'stop':stop,'settings':sn,'targets':targets})
# Recover partial instantaneous coefficients from amplitude jets in a chosen Schr lift.
errs=[]
for t in [.01,.1,.3,.5]:
 a=v(0,t)[:,0];h=m.H[0]+m.H[1]*t+m.H[2]*t*t;ad=-1j*h@a;gprev=0;ee=[];gg=[]
 for n in range(4):
  y=1j*ad[n]/a[n];previous=gprev*a[n-1]/a[n] if n else 0;g=float((y-previous).imag/(a[n+1]/a[n]).imag);e=float((y-previous-g*a[n+1]/a[n]).real);gg.append(g);ee.append(e);gprev=g
 errs.append({'time':t,'maximum_error':float(max(np.max(abs(np.array(gg)-np.diag(h,1)[:4])),np.max(abs(np.array(ee)-np.diag(h)[:4]))))})
out['partial_reconstruction']=errs
projective=[]
for t in [.3,.5]:
 c=v(0,t)[:,0];h=m.H[0]+m.H[1]*t+m.H[2]*t*t;dc=-1j*h@c;z=c/c[0];dz=(dc*c[0]-c*dc[0])/c[0]**2;p0=float(abs(c[0])**2);dp0=float(2*np.real(c[0].conjugate()*dc[0]));aa=np.sqrt(p0)*z;da=np.sqrt(p0)*dz+dp0*z/(2*np.sqrt(p0));previous=0;gg=[];ee=[]
 for n in range(4):
  yy=1j*da[n]/aa[n];old=previous*aa[n-1]/aa[n] if n else 0;gn=float((yy-old).imag/(aa[n+1]/aa[n]).imag);en=float((yy-old-gn*aa[n+1]/aa[n]).real);gg.append(gn);ee.append(en);previous=gn
 projective.append({'time':t,'g0_population_formula_error':float(abs(dp0/(2*p0*z[1].imag)-h[0,1])),'maximum_coupling_and_energy_offset_error':float(max(np.max(abs(np.array(gg)-np.diag(h,1)[:4])),np.max(abs(np.array(ee)-ee[0]-(np.diag(h)[:4]-h[0,0])))))})
out['partial_projective_with_reference_population']=projective
_output_path(R / 'access_designs.json').write_text(json.dumps(_record_environment(out),indent=2));print('gap:',out['gap']);print('Gaussian:',out['gaussian']);print('Multinomial:',[(r['design'],r['targets']['E3(0)-E0(0)']) for r in out['multinomial']])
