"""High-precision equal-copy Fisher check for the weak early three-level design."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import sys,json,math,time
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'fisher/dependencies'))
import mpmath as mp
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent
E=[['.12','.37','1.91','.82','3.44','1.27'],['.07','-.13','.05','.19','-.11','.03'],['.02','-.01','.04','-.03','.01','.05']];G=[['.73','1.11','.58','.94','.67'],['-.19','.08','.14','-.05','.09'],['.06','-.02','.03','.04','-.01']]
def run(dps,order):
 mp.mp.dps=dps;hs=[]
 for q in range(3):
  h=mp.matrix(6)
  for j in range(6):h[j,j]=mp.mpf(E[q][j])/math.factorial(q)
  for j in range(5):h[j,j+1]=h[j+1,j]=mp.mpf(G[q][j])/math.factorial(q)
  hs.append(h)
 C=[mp.matrix(6,25)];C[0][0,0]=1
 for k in range(order):
  term=mp.matrix(6,25)
  for q in range(min(k,2)+1):term+=hs[q]*C[k-q]
  for col,(kind,j,q) in enumerate(m.PARAMS,1):
   if k<q:continue
   if kind=='E':term[j,col]+=C[k-q][j,0]/math.factorial(q)
   else:term[j,col]+=C[k-q][j+1,0]/math.factorial(q);term[j+1,col]+=C[k-q][j,0]/math.factorial(q)
  C.append(term*(-mp.j/(k+1)))
 gram=mp.matrix(24)
 for it in range(61):
  t=mp.mpf('.24')*(mp.mpf('.1')+mp.mpf('.9')*it/60);v=C[-1].copy()
  for a in C[-2::-1]:v=v*t+a
  rows=[];p=abs(v[0,0])**2;dp=[2*mp.re(mp.conj(v[0,0])*v[0,j+1]) for j in range(24)]
  rows.extend([[a/mp.sqrt(p) for a in dp],[-a/mp.sqrt(1-p) for a in dp]])
  for n in range(1,4):
   for phase in [mp.mpf(1),mp.j]:
    for sign in [1,-1]:
     amp=(v[0,0]+sign*phase*v[n,0])/mp.sqrt(2);dd=[2*mp.re(mp.conj(amp)*(v[0,j+1]+sign*phase*v[n,j+1])/mp.sqrt(2)) for j in range(24)];rows.append([a/abs(amp) for a in dd])
    rest=[j for j in range(6) if j not in [0,n]];pp=sum(abs(v[j,0])**2 for j in rest);dd=[2*mp.re(sum(mp.conj(v[j,0])*v[j,col+1] for j in rest)) for col in range(24)];rows.append([a/mp.sqrt(pp) for a in dd])
  jmat=mp.matrix(rows);gram+=jmat.T*jmat/(61*7)
  if it%20==0:print(dps,it,flush=True)
 norms=[mp.sqrt(gram[i,i]) for i in range(24)];gn=mp.matrix([[gram[i,j]/(norms[i]*norms[j]) for j in range(24)] for i in range(24)]);vals={}
 for name in ['energy','coupling','rate']:
  b=mp.matrix(24,1)
  if name=='energy':b[m.TARGET]=1
  elif name=='coupling':b[m.PARAMS.index(('g',2,0))]=1
  else:b[m.PARAMS.index(('g',2,0))]=-mp.mpf('.14')/mp.mpf('.58')**2;b[m.PARAMS.index(('g',2,1))]=1/mp.mpf('.58')
  bb=mp.matrix([b[i]/norms[i] for i in range(24)]);value=mp.sqrt((bb.T*mp.lu_solve(gn,bb))[0]);vals[name]={'sd_times_sqrt_total_copies':mp.nstr(value,25),'sd_at_B_427e12':mp.nstr(value/mp.sqrt(mp.mpf('4.27e12')),25)}
 return {'dps':dps,'Taylor_order':order,'bounds':vals}
if __name__=='__main__':
 runs=[run(40,50),run(60,70)];_output_path(R / 'high_precision_counts.json').write_text(json.dumps(_record_environment({'runs':runs}),indent=2));print(runs)
