"""High-precision independent check of the partial instantaneous recursion."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'fisher/dependencies'))
import mpmath as mp,json,math
R=Path(__file__).parent;mp.mp.dps=60
E=[['.12','.37','1.91','.82','3.44','1.27'],['.07','-.13','.05','.19','-.11','.03'],['.02','-.01','.04','-.03','.01','.05']];G=[['.73','1.11','.58','.94','.67'],['-.19','.08','.14','-.05','.09'],['.06','-.02','.03','.04','-.01']];hs=[]
for q in range(3):
 h=mp.matrix(6)
 for j in range(6):h[j,j]=mp.mpf(E[q][j])/math.factorial(q)
 for j in range(5):h[j,j+1]=h[j+1,j]=mp.mpf(G[q][j])/math.factorial(q)
 hs.append(h)
C=[mp.matrix([1,0,0,0,0,0])]
for k in range(70):C.append(-mp.j*sum((hs[q]*C[k-q] for q in range(min(k,2)+1)),mp.matrix(6,1))/(k+1))
rows=[]
for ts in ['.01','.1','.3','.5']:
 t=mp.mpf(ts);c=C[-1].copy()
 for a in C[-2::-1]:c=c*t+a
 h=hs[0]+hs[1]*t+hs[2]*t*t;dc=-mp.j*h*c;previous=0;errors=[]
 for n in range(4):
  yy=mp.j*dc[n]/c[n];old=previous*c[n-1]/c[n] if n else 0;gn=mp.im(yy-old)/mp.im(c[n+1]/c[n]);en=mp.re(yy-old-gn*c[n+1]/c[n]);errors.extend([abs(gn-h[n,n+1]),abs(en-h[n,n])]);previous=gn
 rows.append({'time':ts,'maximum_partial_recursion_error':mp.nstr(max(errors),8)})
_output_path(R / 'high_precision_partial.json').write_text(json.dumps(_record_environment({'dps':60,'Taylor_order':70,'rows':rows}),indent=2));print(rows)
