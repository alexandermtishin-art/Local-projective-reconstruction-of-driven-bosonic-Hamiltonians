"""Independent ODE sensitivity check, generic-map conditioning and denominator SNR."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import math,json
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent;xs=np.linspace(.024,.716,101);checks=[];ode_solutions={}
for k in [0,2]:
 init=np.zeros((6,25),complex);init[k,0]=1
 def rhs(t,y):
  c=y.reshape(6,25);h=m.H[0]+m.H[1]*t+m.H[2]*t*t;out=h@c
  for col,(_,_,q) in enumerate(m.PARAMS,1):out[:,col]+=m.D[col-1]@c[:,0]*t**q
  return (-1j*out).ravel()
 sol=solve_ivp(rhs,(0,.716),init.ravel(),t_eval=xs,method='DOP853',rtol=2e-13,atol=2e-15,dense_output=True);ode_solutions[k]=sol.sol;ode=sol.y.T.reshape(-1,6,25);series=np.array([m.eval_series(m.series(k),t) for t in xs]);checks.append({'site':k,'max_state_and_sensitivity_difference':float(np.max(abs(ode-series)))})
N=5;h=m.H[0][:N,:N];times=np.geomspace(.005,.03,20);conds=[]
for t in times:
 c=expm(-1j*h*t)[:,0];cols=[]
 for kind,js in [('E',range(1,N)),('g',range(N-1))]:
  for j in js:
   b=np.zeros((N,N))
   if kind=='E':b[j,j]=1
   else:b[j,j+1]=b[j+1,j]=1
   w=-1j*(b@c-c*np.vdot(c,b@c));cols.append(np.r_[w.real,w.imag])
 s=np.linalg.svd(np.array(cols).T,compute_uv=False);conds.append(float(s[0]/s[-1]))
snr=[]
for T in [.015,.03,.06,.12,.24,.48]:
 c=m.series(0)[:,:,0];v=np.array([m.eval_series(c,t) for t in np.linspace(T/10,T,61)]);z=v/v[:,0,None];x=np.linspace(.1,1,61);values={}
 for extra in [2,3]:
  P=np.linalg.pinv(x[:,None]**np.arange(3,4+extra));co=z[:,3]@P.T;values[f'degree_n_plus_{extra}']=float(abs(co[0])/(1e-8*np.linalg.norm(P[0])))
 snr.append({'T':T,'third_onset_denominator_SNR_at_sigma1e8':values['degree_n_plus_2'],'by_fit_degree':values})
b=np.zeros(24);b[m.TARGET]=1;fisher=[]
for start,stop,design,name in [(.024,.24,[(0,[1,2,3])],'early3'),(.024,.24,[(0,[1,2,3,4])],'early4'),(.192,.408,[(0,[1,2,3,4])],'later03'),(.392,.608,[(0,[1,2,3,4])],'later05'),(.024,.24,[(0,[1]),(2,[1,3])],'two')]:
 sn=sum(1+2*len(ns) for k,ns in design);values=[]
 for method in ['series','ODE']:
  rows=[]
  for k,ns in design:
   cc=m.series(k)
   for t in np.linspace(start,stop,61):
    vv=m.eval_series(cc,t) if method=='series' else ode_solutions[k](t).reshape(6,25)
    rows.append(m.rows(vv,k,ns))
  J=np.vstack(rows)/np.sqrt(61*sn);norm=np.linalg.norm(J,axis=0);u,ss,vh=np.linalg.svd(J/norm,full_matrices=False);values.append(float(np.linalg.norm((vh@(b/norm))/ss)))
 fisher.append({'design':name,'energy_sd_times_sqrt_copies_series_and_ODE':values,'relative_difference':float(abs(values[0]/values[1]-1))})
out={'Fisher_independent_ODE_checks':fisher,'ODE_checks':checks,'conditioning':{'dimension':5,'class':'static nominal first-five block; fixed E0 gauge; unscaled projective state-derivative map','times':times.tolist(),'conditions':conds,'loglog_slope':float(np.polyfit(np.log(times),np.log(conds),1)[0])},'denominator_SNR':snr}
_output_path(R / 'independent_numerics.json').write_text(json.dumps(_record_environment(out),indent=2));print(checks,out['conditioning']['loglog_slope'],snr);print(fisher)
