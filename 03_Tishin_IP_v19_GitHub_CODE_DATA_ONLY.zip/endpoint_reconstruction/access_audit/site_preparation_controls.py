"""Independent exact Lindblad jets and noiseless preparation controls (hbar=1).

All inputs are explicit. Density jets test rate aliases. Finite-window cubic
fits are separate biased estimators, not tests of exact-jet invariance.
Outputs are written into regenerated/, never over manuscript archives.
"""
import json, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp

E=np.array([.12,.37,1.91,.82,3.44,1.27])
ED=np.array([.07,-.13,.05,.19,-.11,.03])
EDD=np.array([.02,-.01,.04,-.03,.01,.05])
G=np.array([.73,1.11,.58,.94,.67])
GD=np.array([-.19,.08,.14,-.05,.09])
GDD=np.array([.06,-.02,.03,.04,-.01])

def mat(e,g): return np.diag(e)+np.diag(g,1)+np.diag(g,-1)
H=[mat(e,g)/[1,1,2][q] for q,(e,g) in enumerate(zip([E,ED,EDD],[G,GD,GDD]))]

def diss(r,j):
    q=j.conj().T@j
    return j@r@j.conj().T-(q@r+r@q)/2

def noise_jets():
    rng=np.random.default_rng(20261015); N=18; order=6
    a=np.diag(np.sqrt(np.arange(1,N)),1); a2=a@a; rows=[]
    for trial in range(40):
        B=np.zeros((N,N),complex); Bd=B.copy()
        gs=rng.uniform(.3,1.3,8); gds=rng.uniform(-.3,.3,8)
        ev=np.arange(0,N,2); od=np.arange(1,N,2)
        B[np.ix_(ev,ev)]=mat(rng.normal(size=9),gs)
        Bd[np.ix_(ev,ev)]=mat(rng.normal(size=9),gds)
        Q=rng.normal(size=(9,9)); B[np.ix_(od,od)]=(Q+Q.T)/2
        kap=float(rng.uniform(.01,.1))
        def L(r):return -1j*(B@r-r@B)+kap*diss(r,a2)
        rr=np.zeros((order+1,N,N),complex);rr[0,0,0]=1
        for m in range(order):
            rhs=L(rr[m])
            if m:rhs+=-1j*(Bd@rr[m-1]-rr[m-1]@Bd)
            rr[m+1]=rhs/(m+1)
        zz=np.zeros((order+1,9),complex)
        for m in range(order+1):zz[m]=rr[m,::2,0]-sum(rr[j,0,0]*zz[m-j] for j in range(1,m+1))
        inc=[]; prev=0
        for n in range(1,5):
            R=(n+1)*zz[n+1,n]/zz[n,n]
            chi=(R-prev).real/n;prev=R
            expect=gds[n-1]/gs[n-1]-kap*(2*n-1)
            inc.append({'n':n,'rate':float(chi),'expected':float(expect),'error':float(abs(chi-expect))})
        site=[]
        for k in [0,1,2,3]:
            p=2*k;q=p+2;r=np.zeros_like(B);r[p,p]=1; dr=L(r);dd=L(dr)-1j*(Bd@r-r@Bd)
            ratio=(dd[q,p]-2*dr[q,p]*dr[p,p])/dr[q,p]
            expect=gds[k]/gs[k]-kap*(4*k+1)
            site.append({'k':k,'rate':float(ratio.real),'expected':float(expect),'error':float(abs(ratio.real-expect))})
        observed=(site[2]['rate']-site[0]['rate'])-(gds[2]/gs[2]-gds[0]/gs[0])
        rows.append({'kappa2':kap,'vacuum':inc,'site':site,'difference_alias':float(observed),'difference_expected':-8*kap})
    return {'seed':20261015,'cutoff':N,'trials':rows,'vacuum_max_error':max(z['error'] for r in rows for z in r['vacuum']), 'site_max_error':max(z['error'] for r in rows for z in r['site']), 'difference_max_error':max(abs(r['difference_alias']-r['difference_expected']) for r in rows)}

T=.24; times=np.linspace(.024,T,61)
def propagate(envelope=False,ramp=0):
    def rhs(t,v):
        B=sum(H[q]*t**q for q in range(3))
        if envelope:
            gg=G*(1+.2*t+.02*t*t); ee=E+ED*t+EDD*t*t/2
            B=mat(ee,gg)
        if ramp:B=np.diag(np.diag(B))+(B-np.diag(np.diag(B)))*(1-np.exp(-t/ramp))
        return (-1j*B@v.reshape(6,6)).ravel()
    sol=solve_ivp(rhs,[0,T],np.eye(6,dtype=complex).ravel(),t_eval=times,method='DOP853',rtol=2e-13,atol=2e-15)
    assert sol.success
    return sol.y.T.reshape(-1,6,6)

def estimates(U,eps=0,phase=0,free=False,incoherent=False,offset=0):
    all_edges=[]
    for prep,obs in [(0,[1]),(2,[1,3])]:
        Up=U[prep] if isinstance(U,dict) else U
        if incoherent:
            pp=eps; c=Up[:,:,prep];d=Up[:,:,prep+1]
            rho=(1-pp)*c[:,:,None]*c[:,None,:].conj()+pp*d[:,:,None]*d[:,None,:].conj()
            zs=rho[:,obs,prep].T/rho[:,prep,prep]
        else:
            c=np.sqrt(1-eps*eps)*Up[:,:,prep]+eps*np.exp(1j*phase)*Up[:,:,prep+1]
            zs=c[:,obs].T/c[:,prep]
        powers=np.arange(0 if free else 1,4); A=(times/T)[:,None]**powers
        fit=(zs+offset)@np.linalg.pinv(A).T/T**powers
        a=fit[:,np.where(powers==1)[0][0]];b=fit[:,np.where(powers==2)[0][0]]
        ratios=2*b/a
        for j,r,aa in zip(obs,ratios,a):all_edges.append({'prep':prep,'observed':j,'rate':float(r.real),'energy':float(-r.imag),'g_estimate':float(abs(aa))})
    return {'energy':all_edges[0]['energy']-all_edges[1]['energy']+all_edges[2]['energy'],'rate_difference':all_edges[2]['rate']-all_edges[0]['rate'],'edges':all_edges}

def coherent_exact(eps,phase):
    edge=[]
    for prep,obs in [(0,[1]),(2,[1,3])]:
        c=np.zeros(6,complex);c[prep]=np.sqrt(1-eps*eps);c[prep+1]=eps*np.exp(1j*phase)
        d=-1j*H[0]@c;dd=-1j*H[1]@c-H[0]@H[0]@c
        for j in obs:
            wp=d[j]/c[prep]-c[j]*d[prep]/c[prep]**2
            wpp=dd[j]/c[prep]-c[j]*dd[prep]/c[prep]**2-2*d[j]*d[prep]/c[prep]**2+2*c[j]*d[prep]**2/c[prep]**3
            R=wpp/wp;edge.append((-R.imag,R.real))
    return {'energy':float(edge[0][0]-edge[1][0]+edge[2][0]),'rate_difference':float(edge[2][1]-edge[0][1])}

def preparation_controls():
    U=propagate(); rows=[]
    for eps in [.01,.03,.1]:
        for free in [False,True]:
            vals=[estimates(U,eps,ph,free) for ph in np.linspace(0,2*np.pi,65)[:-1]]
            rows.append({'type':'coherent','epsilon_amplitude':eps,'free_constant':free,'phases':64,'energy_range':[min(v['energy'] for v in vals),max(v['energy'] for v in vals)],'difference_range':[min(v['rate_difference'] for v in vals),max(v['rate_difference'] for v in vals)]})
    for eps in [.01,.03,.1]:
        vals=[coherent_exact(eps,ph) for ph in np.linspace(0,2*np.pi,65)[:-1]]
        rows.append({'type':'coherent_exact_jet','epsilon_amplitude':eps,'phases':64,'energy_range':[min(v['energy'] for v in vals),max(v['energy'] for v in vals)],'difference_range':[min(v['rate_difference'] for v in vals),max(v['rate_difference'] for v in vals)]})
    for free in [False,True]:rows.append({'type':'incoherent','neighbor_population':.02,'free_constant':free,**estimates(U,.02,free=free,incoherent=True)})
    exact=[]
    for prep,obs in [(0,[1]),(2,[1,3])]:
        for mixed in [False,True]:
            r=np.zeros((6,6),complex);r[prep,prep]=.98 if mixed else 1
            if mixed:r[prep+1,prep+1]=.02
            dr=-1j*(H[0]@r-r@H[0]); dd=-1j*(H[0]@dr-dr@H[0])-1j*(H[1]@r-r@H[1])
            for j in obs:
                ratio=(dd[j,prep]/r[prep,prep]-2*dr[j,prep]*dr[prep,prep]/r[prep,prep]**2)/(dr[j,prep]/r[prep,prep])
                idx=min(prep,j);exact.append({'prep':prep,'observed':j,'incoherent':mixed,'rate':float(ratio.real),'true_rate':float(GD[idx]/G[idx]),'g_estimate':float(abs(dr[j,prep]/r[prep,prep]))})
    ramps=[]
    for env in [False,True]:
        for ramp in [0,.002]:
            v=estimates(propagate(env,ramp));ramps.append({'common_envelope':env,'ramp_site0':ramp,'ramp_site2':ramp,**v})
        v=estimates({0:propagate(env,.002),2:propagate(env,.0022)})
        ramps.append({'common_envelope':env,'ramp_site0':.002,'ramp_site2':.0022,**v})
    return {'window':[.024,.24],'points':61,'fit_degree':3,'ideal_constrained':estimates(U),'ideal_free_constant':estimates(U,free=True),'true_energy':float(E[3]-E[0]),'true_difference':float(GD[2]/G[2]-GD[0]/G[0]),'coherent_phase_scan':rows,'exact_incoherent_jets':exact,'ramps':ramps}

if __name__=='__main__':
    result={'description':__doc__,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'convention':'hbar=1; D[L]rho=LrhoLdag-{LdagL,rho}/2; epsilon is coherent amplitude, .02 is incoherent population','two_photon_loss':noise_jets(),'preparation':preparation_controls()}
    dest=Path(__file__).parent/'regenerated'/Path(__file__).with_suffix('.json').name;dest.parent.mkdir(exist_ok=True);dest.write_text(json.dumps(result,indent=2))
    print(json.dumps({'noise_errors':{k:v for k,v in result['two_photon_loss'].items() if k.endswith('error')},'preparation':result['preparation']},indent=2))
