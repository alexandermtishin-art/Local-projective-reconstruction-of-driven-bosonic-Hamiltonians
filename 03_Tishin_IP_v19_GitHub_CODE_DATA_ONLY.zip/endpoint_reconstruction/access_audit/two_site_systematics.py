import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

"""Noiseless paired-preparation ramp and additive-offset controls."""
from pathlib import Path
import sys,json,platform
import numpy as np
import scipy
from scipy.integrate import solve_ivp
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent;times=np.linspace(.024,.24,61);x=times/.24;P=np.linalg.pinv(x[:,None]**np.arange(1,4));rows=[]
for name,ramp0,ramp2,offset in [('ideal',0,0,0),('common_ramp',.002,.002,0),('mismatched_ramp',.002,.0022,0),('offset_1e6',0,0,1e-6),('offset_1e5',0,0,1e-5)]:
 estimates=[]
 for prep,edges,tr in [(0,[1],ramp0),(2,[1,3],ramp2)]:
  def rhs(t,c):
   H=sum(m.H[q]*t**q for q in range(3)).copy()
   if tr:H=np.diag(np.diag(H))+(H-np.diag(np.diag(H)))*(1-np.exp(-t/tr))
   return -1j*H@c
  c0=np.zeros(6,complex);c0[prep]=1;sol=solve_ivp(rhs,[0,.24],c0,t_eval=times,method='DOP853',rtol=2e-13,atol=2e-15)
  assert sol.success
  for j in edges:
   co=(sol.y[j]/sol.y[prep]+offset)@P.T/np.array([.24,.24**2,.24**3]);ratio=2*co[1]/co[0];estimates.append({'prep':prep,'observed':j,'edge':min(j,prep),'g':float(abs(co[0])),'local_energy_offset':float(-ratio.imag),'rate':float(ratio.real)})
 energy=estimates[0]['local_energy_offset']-estimates[1]['local_energy_offset']+estimates[2]['local_energy_offset'];D=estimates[2]['rate']-estimates[0]['rate']
 rows.append({'model':name,'ramp0':ramp0,'ramp2':ramp2,'real_offset_each_ratio':offset,'E3_minus_E0_estimate':energy,'rate_difference_edge2_edge0':D,'edge_estimates':estimates})
out={'model':'six-level quadratic chain; cubic fits of adjacent ratios, 61 times [.024,.24]; pure site preparations; no shot noise','true_E3_minus_E0':float(m.E[3]-m.E[0]),'true_rate_difference_edge2_edge0':float(m.GD[2]/m.G[2]-m.GD[0]/m.G[0]),'rows':rows,'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__}}
_output_path(R / 'two_site_systematics.json').write_text(json.dumps(_record_environment(out),indent=2));print(json.dumps(_record_environment(out),indent=2))
