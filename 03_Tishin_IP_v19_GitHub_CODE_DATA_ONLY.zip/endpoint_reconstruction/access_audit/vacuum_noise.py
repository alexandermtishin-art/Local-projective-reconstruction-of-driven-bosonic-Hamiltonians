"""Onset-rate aliases under loss, gain and linear number dephasing."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import numpy as np,json
N=16;order=7;n=np.arange(N);a=np.diag(np.sqrt(np.arange(1,N)),1);num=np.diag(n);H=[np.diag(.12*n+.017*n*(n-1))+.31*(a@a+a.T@a.T),.08*(a@a+a.T@a.T)];rows=[]
def diss(L,r):Q=L.conj().T@L;return L@r@L.conj().T-.5*(Q@r+r@Q)
for km,kp,gamma in [(.03,0,0),(.03,.02,0),(.03,.02,.005)]:
 rho=np.zeros((order+1,N,N),complex);rho[0,0,0]=1
 for k in range(order):
  rhs=sum(-1j*(H[q]@rho[k-q]-rho[k-q]@H[q]) for q in range(min(1,k)+1));rhs+=km*diss(a,rho[k])+kp*diss(a.T,rho[k])+gamma*diss(num,rho[k]);rho[k+1]=rhs/(k+1)
 z=np.zeros((order+1,8),complex)
 for k in range(order+1):z[k]=rho[k,::2,0]-sum(rho[j,0,0]*z[k-j] for j in range(1,k+1))
 rates=[];previous=0
 for j in range(1,5):rr=(j+1)*z[j+1,j]/z[j,j];rates.append(float((rr-previous).real/j));previous=rr
 expected=[.08/.31-km-kp-2*gamma*j for j in range(1,5)];error=float(max(abs(np.array(rates)-expected)));assert error<1e-12
 rows.append({'kappa_minus':km,'kappa_plus':kp,'gamma':gamma,'vacuum_onset_inferred_rates':rates,'expected':expected,'max_error':error})
_output_path(Path(__file__).with_suffix('.json')).write_text(json.dumps(_record_environment(rows),indent=2));print(rows)
