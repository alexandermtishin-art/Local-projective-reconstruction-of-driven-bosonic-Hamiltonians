"""Admissible compact-prior van Trees matrix for the stated quadratic S3 class."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import sys,json,math,platform
import numpy as np
import scipy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common'))
import protocol_core as m
R=Path(__file__).parent
base=np.array([([m.E,m.ED,m.EDD] if kind=='E' else [m.G,m.GD,m.GDD])[q][j] for kind,j,q in m.PARAMS]);sd=np.array([.1 if kind=='E' else .1*m.G[j] for kind,j,q in m.PARAMS]);w=np.sqrt(7)*sd
# Independent Beta(3,3) marginals on mean +/- sqrt(7)*sd, exact var sd^2.
Iprior=10/w**2;times=np.linspace(.024,.24,61);order=50
powers=times[:,None]**np.arange(order+1)
def J(theta):
 H=np.array(m.H).copy()
 for i,(v,b,d) in enumerate(zip(theta,base,m.D)):H[m.PARAMS[i][2]]+=(v-b)*d
 C=np.zeros((order+1,6,25),complex);C[0,0,0]=1
 for k in range(order):
  term=sum(H[q]@C[k-q] for q in range(min(k,2)+1))
  for col,(_,_,q) in enumerate(m.PARAMS):
   if k>=q:term[:,col+1]+=m.D[col]@C[k-q,:,0]
  C[k+1]=-1j*term/(k+1)
 vals=np.einsum('tk,kij->tij',powers,C);z=(vals[:,1:4,1:]*vals[:,0,0,None,None]-vals[:,1:4,0,None]*vals[:,0,1:,None].transpose(0,2,1))/vals[:,0,0,None,None]**2
 return np.vstack([z.real.reshape(-1,24),z.imag.reshape(-1,24)]),float(np.min(abs(vals[:,0,0])))
def bound(A):
 norms=np.sqrt(np.diag(A));B=A/norms[:,None]/norms[None,:];b=np.zeros(24);b[m.TARGET]=1/norms[m.TARGET];return float(np.sqrt(b@np.linalg.solve(B,b))),float(np.linalg.eigvalsh(B)[0])
rng=np.random.default_rng(20261014);grams=[];minc=1
for i in range(200):
 theta=base+w*(2*rng.beta(3,3,24)-1);a,c=J(theta);grams.append(a.T@a/1e-16);minc=min(minc,c)
np.savez_compressed(_output_path(R/'prior_information_samples.npz'),grams=np.array(grams), provenance=np.array(json.dumps(_record_environment({'status':'regenerated','generator':Path(__file__).name}))));mean=np.mean(grams,axis=0);prior=np.diag(Iprior);full=bound(mean+prior);splits=[bound(np.mean(grams[a:b],axis=0)+prior)[0] for a,b in [(0,100),(100,200)]];nominal,_=J(base);point=bound(nominal.T@nominal/1e-16+prior)
boot_rng=np.random.default_rng(2026101401);boot=[bound(np.mean(np.array(grams)[boot_rng.integers(0,200,200)],axis=0)+prior)[0] for _ in range(2000)];boot_ci=np.quantile(boot,[.025,.975]).tolist()
# Uniform support bound from Gershgorin, positive polynomial coefficients bounded below.
Emax=[];Gmin=[];Gmax=[]
lo=base-w;hi=base+w
for j in range(6):
 if j in range(1,5):Es=[max(abs(lo[m.PARAMS.index(('E',j,q))]),abs(hi[m.PARAMS.index(('E',j,q))])) for q in range(3)]
 else:Es=[abs(x[j]) for x in [m.E,m.ED,m.EDD]]
 Emax.append(Es[0]+Es[1]*.24+Es[2]*.24**2/2)
for j in range(5):
 if j<4:ls=[lo[m.PARAMS.index(('g',j,q))] for q in range(3)];us=[hi[m.PARAMS.index(('g',j,q))] for q in range(3)]
 else:ls=us=[m.G[j],m.GD[j],m.GDD[j]]
 Gmin.append(ls[0]-abs(ls[1])*.24-abs(ls[2])*.24**2/2);Gmax.append(us[0]+max(abs(ls[1]),abs(us[1]))*.24+max(abs(ls[2]),abs(us[2]))*.24**2/2)
hmax=max(Emax[j]+(Gmax[j-1] if j else 0)+(Gmax[j] if j<5 else 0) for j in range(6));gamma=math.cos(.24*hmax);assert min(Gmin)>0 and gamma>0
out={'seed':20261014,'draws':200,'sigma':1e-8,'prior':'independent compact Beta(3,3); energies sd .1; coupling q=0,1,2 sd .1*g_j(0); supplied coefficients fixed','means':base.tolist(),'halfwidths':w.tolist(),'prior_information_diagonal':Iprior.tolist(),'uniform_support_coupling_lower':min(Gmin),'uniform_support_H_norm_upper':hmax,'uniform_chart_amplitude_lower':gamma,'sample_min_c0':minc,'van_Trees_Bayesian_RMSE_lower':full[0],'split_half_bounds':splits,'prior_integration_bootstrap_95_percentile':boot_ci,'bootstrap_draws':2000,'bootstrap_seed':2026101401,'pointwise_regularized_scale':point[0],'normalized_min_eigenvalue':full[1],'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__}}
_output_path(R / 'bayesian_information.json').write_text(json.dumps(_record_environment(out),indent=2));print(out)
