
import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import sys,math,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
sys.path.insert(0,str(BASE/'fisher'))
from extended_fisher import E,ED,EDD,G,GD,GDD,PARAMS,TARGET,polynomial
H=[(np.diag(e)+np.diag(g,1)+np.diag(g,-1))/math.factorial(q) for q,(e,g) in enumerate(zip([E,ED,EDD],[G,GD,GDD]))]
C=np.zeros((71,6,25),complex);C[0,0,0]=1
for k in range(70):
 term=sum(H[q]@C[k-q] for q in range(min(k,2)+1))
 for col,(kind,j,q) in enumerate(PARAMS,1):
  if k>=q:
   if kind=='E':term[j,col]+=C[k-q,j,0]/math.factorial(q)
   else:
    term[j,col]+=C[k-q,j+1,0]/math.factorial(q);term[j+1,col]+=C[k-q,j,0]/math.factorial(q)
 C[k+1]=-1j*term/(k+1)
def evaluate(t):
 v=C[-1].copy()
 for c in C[-2::-1]:v=v*t+c
 return v
def data(T,levels=(1,2,3)):
 vv=np.array([evaluate(t) for t in np.linspace(T/10,T,61)])
 dz=np.stack([(vv[:,n,1:]*vv[:,0,0,None]-vv[:,n,0,None]*vv[:,0,1:])/vv[:,0,0,None]**2 for n in levels],axis=1)
 cj=dz.reshape(-1,24);return np.vstack([cj.real,cj.imag]),vv[:,1:4,0]/vv[:,0,0,None]
def inflation(J,idx):
 v=J[:,TARGET];ids=[i for i in idx if i!=TARGET];N=J[:,ids];N=N/np.linalg.norm(N,axis=0)
 U,s,V=np.linalg.svd(N,full_matrices=False);res=v-U@(U.T@v)
 return {'sd_inflation':float(np.linalg.norm(v)/np.linalg.norm(res)),'sd_per_unit_sigma':float(1/np.linalg.norm(res)),'smallest_nuisance_singular':float(s[-1])}
sets={
 'S1':[i for i,(kind,j,q) in enumerate(PARAMS) if q==0 and j<=(3 if kind=='E' else 2)],
 'S2':[i for i,(kind,j,q) in enumerate(PARAMS) if q<=1 and j<=(3 if kind=='E' else 2)],
 'first_three_quadratic':[i for i,(kind,j,q) in enumerate(PARAMS) if j<=(3 if kind=='E' else 2)],
 'plus_deeper_values':[i for i,(kind,j,q) in enumerate(PARAMS) if j<=(3 if kind=='E' else 2) or q==0],
 'plus_deeper_first':[i for i,(kind,j,q) in enumerate(PARAMS) if j<=(3 if kind=='E' else 2) or q<=1],
 'S3':list(range(24)),
 'S3_without_E4':[i for i,(kind,j,q) in enumerate(PARAMS) if not(kind=='E' and j==4)]}
out={'fisher':[]}
for T in [.12,.24,.48]:
 J,z=data(T);p=polynomial(z,T,2,J);b=np.array(list(p['noiseless_estimator_parameter_response'].values()))
 # SVD pseudoinverse with all modes retained: local biased-estimator variance diagnostic.
 U,s,V=np.linalg.svd(J,full_matrices=False);local=float(np.linalg.norm((V@b)/s)*1e-8)
 priors={}
 for tau in [1,.1,.01]:
  # Pointwise regularized Fisher, not integrated van Trees.
  A=J/1e-8;N=np.delete(A,TARGET,axis=1);v=A[:,TARGET]
  aug=np.vstack([N,np.eye(23)/tau]);rhs=np.concatenate([v,np.zeros(23)])
  fit=np.linalg.lstsq(aug,rhs,rcond=None)[0];info=np.linalg.norm(rhs-aug@fit)**2
  priors[str(tau)]=float(1/np.sqrt(info))
 row={'T':T,'models':{k:inflation(J,idx) for k,idx in sets.items()},'local_regularized_fisher_sd_sigma1e8':priors,'local_response_CR_sd_sigma1e8':local,'polynomial_delta_sd_sigma1e8':p['delta_sd_per_unit_sigma']*1e-8}
 out['fisher'].append(row)
 # Generic-time real operator inversion with full lift and projective inputs.
 c=evaluate(T)[:,0];B=[np.eye(6)[:,j,None]@np.eye(6)[j,None,:] for j in range(6)]
 B += [np.diag(np.eye(5)[j],1)+np.diag(np.eye(5)[j],-1) for j in range(5)]
 full=np.array([b@c for b in B]).T;proj=(np.eye(6)-np.outer(c,c.conj()))@full
 for key,M in [('full_lift',full),('projective',proj)]:
  sv=np.linalg.svd(np.vstack([M.real,M.imag]),compute_uv=False)
  row[key]={'rank':int(sum(sv>sv[0]*1e-12)),'singular_values':sv.tolist()}
shot=np.load(BASE/'measurement/measurement_trials.npz');out['shot_joint']=[]
truth=np.array([.58,.70,.14/.58])
for it,T in enumerate([.12,.24,.48]):
 for S in [10**8,10**10,10**12]:
  a=shot[f'shot_T{it}_S{S}'][:,:,2];err=abs(a-truth)/abs(truth)
  out['shot_joint'].append({'T':T,'S':S,'joint_success':int(np.sum(np.all(err<=.1,axis=1))),'trials':len(a),'component_median_relative_errors':np.median(err,axis=0).tolist()})
_output_path(ROOT / 'local_information.json').write_text(json.dumps(_record_environment(out),indent=2)+'\n')
print(json.dumps(_record_environment(out),indent=2))
