"""Exact Taylor-jet check of photon-loss alias in an even Fock ladder."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

from pathlib import Path
import json,math,numpy as np
ROOT=Path(__file__).resolve().parent
N=12;order=9;G=.31;Gdot=.08
n=np.arange(N);a=np.diag(np.sqrt(np.arange(1,N)),1);num=np.diag(n)
E=.12*n+.017*n*(n-1);diag=np.diag(E)
H=[diag+G*(a@a+a.T@a.T),Gdot*(a@a+a.T@a.T)]
rows=[]
for kappa in [0,.03,.2]:
 rho=np.zeros((order+1,N,N),complex);rho[0,0,0]=1
 c=np.zeros((order+1,N),complex);c[0,0]=1
 for k in range(order):
  rhs=sum(-1j*(H[q]@rho[k-q]-rho[k-q]@H[q]) for q in range(min(1,k)+1))
  rhs+=kappa*(a@rho[k]@a.T-.5*(num@rho[k]+rho[k]@num))
  rho[k+1]=rhs/(k+1)
  c[k+1]=(sum(-1j*H[q]@c[k-q] for q in range(min(1,k)+1))-.5*kappa*num@c[k])/(k+1)
 z=np.zeros((order+1,6),complex)
 for k in range(order+1):z[k]=rho[k,::2,0]-sum(rho[j,0,0]*z[k-j] for j in range(1,k+1))
 rates=[];energies=[];previous=0
 for j in range(1,5):
  R=(j+1)*z[j+1,j]/z[j,j]
  rates.append(float((R-previous).real/j));energies.append(float(-(R-previous).imag));previous=R
 # compare unconditional even coherences with no-jump pure density coefficients.
 nojump=np.array([sum(np.outer(c[j],c[k-j].conj()) for j in range(k+1)) for k in range(order+1)])
 rows.append({'kappa':kappa,'odd_population_cubic':float(rho[3,1,1].real),'expected_odd_population_cubic':4*kappa*G**2/3,'true_drive_lograte':Gdot/G,'reconstructed_logrates':rates,'expected_lograte':Gdot/G-kappa,'energy_offsets':energies,'expected_energy_offsets':E[2:10:2].tolist(),'max_rate_error':float(max(abs(np.array(rates)-(Gdot/G-kappa)))),'even_block_feedback_coefficients_norm':[float(np.linalg.norm((rho[k]-nojump[k])[::2,::2])) for k in range(7)]})
assert max(abs(r['odd_population_cubic']-r['expected_odd_population_cubic']) for r in rows)<1e-12
assert max(r['max_rate_error'] for r in rows)<1e-12
_output_path(ROOT / 'loss_alias.json').write_text(json.dumps(_record_environment(rows),indent=2));print(json.dumps(_record_environment(rows),indent=2))
