"""Finite-order test of arbitrary hidden-layer variation and visible-jet matching."""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import math,json
from pathlib import Path
import numpy as np
N=5;ORDER=14;K=2
E=np.array([.12,.37,1.91,.82,3.44]);G=np.array([.73,1.11,.58,.94]);Hd=np.zeros((ORDER,N,N),float)
Hd[0]=np.diag(E)+np.diag(G,1)+np.diag(G,-1)
Hd[1]=np.diag([.07,-.13,.05,.19,-.11])+np.diag([-.19,.08,.14,-.05],1)+np.diag([-.19,.08,.14,-.05],-1)
Hd[2]=(np.diag([.02,-.01,.04,-.03,.01])+np.diag([.06,-.02,.03,.04],1)+np.diag([.06,-.02,.03,.04],-1))/2

def jets(H,order):
 c=np.zeros((order+1,N),complex);c[0,0]=1
 for m in range(order):c[m+1]=-1j*sum((H[q]@c[m-q] for q in range(m+1)),np.zeros(N,complex))/(m+1)
 z=np.zeros_like(c)
 for m in range(order+1):z[m]=c[m]-sum((c[q,0]*z[m-q] for q in range(1,m+1)),np.zeros(N,complex))
 return z
base=jets(Hd,ORDER);rows=[]
for K in [1,2,3]:
 for factor,shift in [(1.6,.4),(.6,-.7)]:
  H=Hd.copy();H[0,K,K+1]=H[0,K+1,K]=G[K]*factor;H[0,K+1,K+1]+=shift
  for m in range(2,ORDER+1):
   for n in range(1,min(K,m-1)+1):
    qg=m-n;qe=m-n-1;H[qg,n-1,n]=H[qg,n,n-1]=0;H[qe,n,n]=0
    residue=base[m,n]-jets(H,m)[m,n]
    prod=np.prod(G[:n-1]);cg=(-1j)**n*prod/(math.factorial(n-1)*m);ce=(-1j)**(n+1)*prod*G[n-1]/(math.factorial(n)*m)
    mat=np.array([[cg.real,ce.real],[cg.imag,ce.imag]]);v=np.linalg.solve(mat,[residue.real,residue.imag]);H[qg,n-1,n]=H[qg,n,n-1]=v[0];H[qe,n,n]=v[1]
  result=jets(H,ORDER);err=float(np.max(abs(result[:,:K+1]-base[:,:K+1])))
  rows.append({'K':K,'hidden_g_factor':factor,'hidden_energy_shift':shift,'max_visible_coefficient_error':err,'max_recovered_control_coefficient':float(np.max(abs(H))),'first_K_couplings_error':float(max(abs(np.diag(H[0],1)[:K]-G[:K]))),'first_K_rates_error':float(max(abs(np.diag(H[1],1)[:K]/G[:K]-np.diag(Hd[1],1)[:K]/G[:K]))),'first_K_energy_error':float(max(abs(np.diag(H[0])[1:K+1]-E[1:K+1])))})
  assert err<1e-11
print(rows);_output_path(Path(__file__).with_suffix('.json')).write_text(json.dumps(_record_environment({'dimension':N,'order':ORDER,'rows':rows}),indent=2))
