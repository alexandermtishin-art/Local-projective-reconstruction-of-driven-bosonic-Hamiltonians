
import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from local_information import evaluate,sets,TARGET,ROOT
import numpy as np,json
out=[]
for T in [.12,.24,.48]:
 F=np.zeros((24,24));Q=np.zeros((24,24))
 for t in np.linspace(T/10,T,61):
  v=evaluate(t);c=v[:,0];s=v[:,1:]
  Q+=7*4*np.real(s.conj().T@s-np.outer(s.conj().T@c,c.conj()@s))
  p0=abs(c[0])**2;dp0=2*np.real(c[0].conjugate()*s[0]);F+=np.outer(dp0,dp0)/(p0*(1-p0))
  for n in [1,2,3]:
   for phase in [1,1j]:
    amp=np.array([(c[0]+phase*c[n])/np.sqrt(2),(c[0]-phase*c[n])/np.sqrt(2)])
    ds=np.array([(s[0]+phase*s[n])/np.sqrt(2),(s[0]-phase*s[n])/np.sqrt(2)])
    prob=abs(amp)**2;der=2*np.real(amp.conj()[:,None]*ds)
    probs=np.append(prob,1-prob.sum());ders=np.vstack([der,-der.sum(axis=0)])
    F+=(ders.T/probs)@ders
 row={'T':T,'total_preparations_per_S':427,'fixed_protocol_sd_per_sqrt_S':float(1/np.sqrt(F[TARGET,TARGET])),'fixed_QFI_sd_per_sqrt_S':float(1/np.sqrt(Q[TARGET,TARGET])),'fixed_QFI_over_protocol_information':float(Q[TARGET,TARGET]/F[TARGET,TARGET])}
 for name in ['S1','S2']:
  idx=sets[name];target=idx.index(TARGET)
  for label,M in [('protocol',F),('SLD_QFI',Q)]:
   A=M[np.ix_(idx,idx)];norm=np.sqrt(np.diag(A));A=A/np.outer(norm,norm)
   row[name+'_'+label+'_sd_per_sqrt_S']=float(np.sqrt(np.linalg.inv(A)[target,target])/norm[target])
 out.append(row)
_output_path(ROOT / 'protocol_information.json').write_text(json.dumps(_record_environment(out),indent=2));print(json.dumps(_record_environment(out),indent=2))
