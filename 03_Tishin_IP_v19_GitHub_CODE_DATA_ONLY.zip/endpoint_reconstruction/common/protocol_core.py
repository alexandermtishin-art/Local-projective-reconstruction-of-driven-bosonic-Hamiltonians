"""Equal-copy classical Fisher comparison for endpoint and local-preparation protocols.
All probabilities use the same quadratic six-level Jacobi family; 24 S3 coordinates.
No singular direction is discarded. Results are local bounds, not estimator performance.
"""
import numpy as np, math,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
E=np.array([.12,.37,1.91,.82,3.44,1.27])
ED=np.array([.07,-.13,.05,.19,-.11,.03])
EDD=np.array([.02,-.01,.04,-.03,.01,.05])
G=np.array([.73,1.11,.58,.94,.67])
GD=np.array([-.19,.08,.14,-.05,.09])
GDD=np.array([.06,-.02,.03,.04,-.01])
BASE=[('E',j) for j in range(1,5)]+[('g',j) for j in range(4)]
PARAMS=[(kind,j,order) for order in range(3) for kind,j in BASE]
LABELS=[f'{kind}{j}_d{order}' for kind,j,order in PARAMS]
TARGET=PARAMS.index(('E',3,0))
MATS=[]
for kind,j,order in PARAMS:
    mat=np.zeros((6,6))
    if kind=='E':mat[j,j]=1
    else:mat[j,j+1]=mat[j+1,j]=1
    MATS.append(mat)
MATS=np.array(MATS)
SETS={
 'S1_instantaneous_first_three': [k for k,(kind,j,order) in enumerate(PARAMS) if order==0 and (j<=3 if kind=='E' else j<=2)],
 'S2_plus_first_derivatives': [k for k,(kind,j,order) in enumerate(PARAMS) if order<=1 and (j<=3 if kind=='E' else j<=2)],
 'S3_plus_deeper_and_second_derivatives':list(range(len(PARAMS)))
}

N=6;P=len(PARAMS);ORDER=70
H=[(np.diag(e)+np.diag(g,1)+np.diag(g,-1))/math.factorial(q) for q,(e,g) in enumerate(zip([E,ED,EDD],[G,GD,GDD]))]
D=[]
for kind,j,q in PARAMS:
 d=np.zeros((N,N));d[j,j]=1 if kind=='E' else 0
 if kind=='g':d[j,j+1]=d[j+1,j]=1
 D.append(d/math.factorial(q))
def series(k,eps=0.,phase=0.,with_spam=False):
 # Known coherent leakage to nearest site, with optional unknown real/imag leakage tangent.
 neighbor=(k+1)%N
 init=np.zeros(N,complex);init[k]=np.sqrt(1-eps**2);init[neighbor]=eps*np.exp(1j*phase)
 extra=2 if with_spam else 0
 C=np.zeros((ORDER+1,N,1+P+extra),complex);C[0,:,0]=init
 if with_spam:
  C[0,neighbor,1+P]=1;C[0,neighbor,2+P]=1j
 for m in range(ORDER):
  term=sum(H[q]@C[m-q] for q in range(min(m,2)+1))
  for col,(_,_,q) in enumerate(PARAMS):
   if m>=q:term[:,col+1]+=D[col]@C[m-q,:,0]
  C[m+1]=-1j*term/(m+1)
 return C
def eval_series(C,t):
 v=C[-1].copy()
 for a in C[-2::-1]:v=v*t+a
 return v
def rows(v,ref,neighbors):
 c=v[:,0];s=v[:,1:];result=[]
 # binomial reference population (two outcomes)
 p=abs(c[ref])**2;dp=2*np.real(c[ref].conjugate()*s[ref]);other=np.delete(np.arange(N),ref)
 pc=float(np.sum(abs(c[other])**2));result.extend([dp/np.sqrt(p),-dp/np.sqrt(pc)])
 for n in neighbors:
  rest=[j for j in range(N) if j not in [ref,n]]
  for phase in [1,1j]:
   amp=np.array([(c[ref]+phase*c[n])/np.sqrt(2),(c[ref]-phase*c[n])/np.sqrt(2)])
   ds=np.array([(s[ref]+phase*s[n])/np.sqrt(2),(s[ref]-phase*s[n])/np.sqrt(2)])
   pp=abs(amp)**2;dd=2*np.real(amp.conj()[:,None]*ds)
   complement=float(np.sum(abs(c[rest])**2));dcomp=2*np.real(np.sum(c[rest].conj()[:,None]*s[rest],axis=0))
   result.extend([dd[0]/np.sqrt(pp[0]),dd[1]/np.sqrt(pp[1]),dcomp/np.sqrt(complement)])
 return np.array(result)
def design(T,protocol,spam=False):
 if protocol=='endpoint':preps=[(0,0,[1,2,3])];settings=7
 elif protocol=='local_three':preps=[(k,k,[k+1]) for k in range(3)];settings=9
 elif protocol=='endpoint_plus_site2':preps=[(0,0,[1,2,3]),(2,0,[1,2,3])];settings=14
 else:raise ValueError(protocol)
 # Separate SPAM coordinates for each preparation, if unknown.
 allrows=[]
 for ip,(k,ref,obs) in enumerate(preps):
  C=series(k,with_spam=spam)
  J=np.vstack([rows(eval_series(C,t),ref,obs) for t in np.linspace(T/10,T,61)])
  if spam:
   block=np.zeros((len(J),P+2*len(preps)));block[:,:P]=J[:,:P];block[:,P+2*ip:P+2*ip+2]=J[:,P:];J=block
  allrows.append(J)
 return np.vstack(allrows)/np.sqrt(61*settings),settings
TARGETS={'g2':PARAMS.index(('g',2,0)),'E3_minus_E0':TARGET,'lograte_g2':None}
def bound(J,indices,functional):
 A=J[:,indices];norm=np.linalg.norm(A,axis=0);An=A/norm
 U,s,Vh=np.linalg.svd(An,full_matrices=False)
 b=functional[indices]/norm
 scale=float(np.linalg.norm((Vh@b)/s))
 return {'sd_times_sqrt_total_copies':scale,'normalized_min_singular':float(s[-1]),'normalized_condition':float(s[0]/s[-1])}
