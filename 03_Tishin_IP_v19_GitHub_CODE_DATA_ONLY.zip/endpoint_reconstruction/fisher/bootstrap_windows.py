#!/usr/bin/env python3
"""Bootstrap stored finite-window samples; no new trial generation.

Percentile bootstrap intervals quantify Monte Carlo uncertainty of the sample
median under the empirical distribution of 200 trials. They are not calibrated
confidence intervals on Hamiltonian parameters or universal optimal-window tests.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json,io,zipfile,hashlib,argparse
from pathlib import Path
import numpy as np
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from extended_fisher import propagate,E

ROOT=Path(__file__).resolve().parent
DATA_ROOT=ROOT.parent
TIMES=[.015,.03,.06,.12,.24,.48,.96]
SIGMAS=[1e-10,1e-8,1e-6]

def bootstrap(x,rng,B=20000):
    reps=x[rng.integers(0,len(x),size=(B,len(x)))]
    med=np.median(reps,axis=1)
    return {'median':float(np.median(x)), 'bootstrap_percentile_95':np.quantile(med,[.025,.975]).tolist(),
            'bootstrap_sd':float(np.std(med,ddof=1)), 'replicates':len(x),'bootstrap_replicates':B}

def noiseless_terms(z,T,p):
    x=np.linspace(.1,1,61);bias={}
    for n in [2,3]:
        pinv=np.linalg.pinv(x[:,None]**np.arange(n,n+p+1)[None,:])
        co=pinv@z[:,n-1]
        r=(n+1)*co[1]/co[0]/T
        truth=np.sum(E[1:n+1]-E[0])
        bias[str(n)]={'minus_Im_R_estimate':float(-r.imag),'minus_Im_R_truth':float(truth),'signed_bias':float(-r.imag-truth)}
    total=bias['3']['signed_bias']-bias['2']['signed_bias']
    return {'R_terms':bias,'energy_signed_bias':total,
            'cancellation_fraction':1-abs(total)/(abs(bias['3']['signed_bias'])+abs(bias['2']['signed_bias']))}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-path',type=Path,default=DATA_ROOT/'jacobi_control',help='Directory containing explicitly selected trial NPZ and summary JSON')
    args=parser.parse_args()
    trials_bytes=(args.input_path/'jacobi_window_trials.npz').read_bytes()
    source_bytes=(args.input_path/'jacobi_window_controls_results.json').read_bytes()
    provenance={'input':str(args.input_path.resolve().relative_to(DATA_ROOT)) if args.input_path.resolve().is_relative_to(DATA_ROOT) else args.input_path.name,'trials_sha256':hashlib.sha256(trials_bytes).hexdigest(),'summary_sha256':hashlib.sha256(source_bytes).hexdigest()}
    npz=np.load(io.BytesIO(trials_bytes))
    source=json.loads(source_bytes)
    biasrows=source['finite_window']['rows']
    rng=np.random.default_rng(2026101003)
    rows=[]
    for it,T in enumerate(TIMES):
        for p in [2,3]:
            for sigma in SIGMAS:
                key=f'T{it}_p{p}_s{sigma}'
                errors=npz[key][:,1,2]-(E[3]-E[0])
                bias=float(next(r for r in biasrows if r['T']==T and r['sigma']==sigma and r['extra_orders']==p)['bias'][1][2])
                rows.append({'T':T,'p':p,'sigma':sigma,'npz_key':key,'signed_noiseless_bias':bias,
                    'absolute_error':bootstrap(abs(errors),rng),'signed_error':bootstrap(errors,rng),
                    'fraction_error_opposite_noiseless_bias':float(np.mean(errors*bias<0)),
                    'fraction_within_10pct_true_offset':float(np.mean(abs(errors)<.07)),
                    'error_q25_q75':np.quantile(errors,[.25,.75]).tolist()})
    components=[]
    for T in [.12,.18,.21,.24,.27,.30,.36,.48]:
        _,trajectory,_=propagate(T,1e-13,1e-16)
        components.append({'T':T,'p2':noiseless_terms(trajectory,T,2),'p3':noiseless_terms(trajectory,T,3)})
    comparisons=[]
    for p in [2,3]:
        for sigma in SIGMAS:
            x=abs(npz[f'T4_p{p}_s{sigma}'][:,1,2]-(E[3]-E[0]))
            for neighbor,it in [(.12,3),(.48,5)]:
                y=abs(npz[f'T{it}_p{p}_s{sigma}'][:,1,2]-(E[3]-E[0]))
                # Groups were independently simulated. Resample independently.
                dx=np.median(x[rng.integers(0,200,(20000,200))],axis=1)
                dy=np.median(y[rng.integers(0,200,(20000,200))],axis=1)
                comparisons.append({'p':p,'sigma':sigma,'comparison':f'median(T=.24)-median(T={neighbor})',
                    'difference':float(np.median(x)-np.median(y)),
                    'bootstrap_percentile_95':np.quantile(dx-dy,[.025,.975]).tolist()})
    result={'provenance':provenance, 'seed':2026101003,
       'bootstrap_replicates':20000,'interpretation':__doc__, 'rows':rows,'noiseless_bias_components':components,'independent_window_comparisons':comparisons}
    _output_path(ROOT / 'bootstrap_windows.json').write_text(json.dumps(_record_environment(result),indent=2)+'\n')
    for r in rows:
        if r['T'] in [.12,.24,.48] and r['sigma']==1e-8:print(r['T'],r['p'],r['absolute_error'], 'signed',r['signed_error']['median'],'bias',r['signed_noiseless_bias'])
    print('T=.24 components',next(r for r in components if r['T']==.24))

if __name__=='__main__':main()
