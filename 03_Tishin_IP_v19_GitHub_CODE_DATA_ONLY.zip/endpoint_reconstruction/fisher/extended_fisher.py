#!/usr/bin/env python3
"""Independent nested-nuisance Fisher and linearized local polynomial check.

No fitting of supplied quadratic laws is performed. Sensitivities are propagated
for instantaneous E1..E4,g0..g3 and their first and second derivatives.
E0 and its derivatives, E5,g4 and their derivatives remain fixed. E3(0) is
the target, all other included coefficients are nuisance. Derivative parameters
multiply t**order/order!, not t**order. Real and imaginary coordinate component
noise is independent with equal sigma. The reported information uses sigma=1.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json, math, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parent
E=np.array([.12,.37,1.91,.82,3.44,1.27])
ED=np.array([.07,-.13,.05,.19,-.11,.03])
EDD=np.array([.02,-.01,.04,-.03,.01,.05])
G=np.array([.73,1.11,.58,.94,.67])
GD=np.array([-.19,.08,.14,-.05,.09])
GDD=np.array([.06,-.02,.03,.04,-.01])
BASE=[('E',j) for j in range(1,5)]+[('g',j) for j in range(4)]
PARAMS=[(kind,j,order) for order in range(3) for kind,j in BASE]
LABELS=[f'{kind}{j}_d{order}' for kind,j,order in PARAMS]
TARGET=PARAMS.index(('E',3,0))
MATS=[]
for kind,j,order in PARAMS:
    mat=np.zeros((6,6))
    if kind=='E':mat[j,j]=1
    else:mat[j,j+1]=mat[j+1,j]=1
    MATS.append(mat)
MATS=np.array(MATS)
SETS={
 'S1_instantaneous_first_three': [k for k,(kind,j,order) in enumerate(PARAMS) if order==0 and (j<=3 if kind=='E' else j<=2)],
 'S2_plus_first_derivatives': [k for k,(kind,j,order) in enumerate(PARAMS) if order<=1 and (j<=3 if kind=='E' else j<=2)],
 'S3_plus_deeper_and_second_derivatives':list(range(len(PARAMS)))
}

def propagate(T,rtol,atol):
    def rhs(t,y):
        v=y.reshape(25,6)
        d=E+ED*t+.5*EDD*t*t;g=G+GD*t+.5*GDD*t*t
        h=np.diag(d)+np.diag(g,1)+np.diag(g,-1)
        out=-1j*v@h.T
        factors=np.array([t**order/math.factorial(order) for _,_,order in PARAMS])
        out[1:]+=-1j*factors[:,None]*np.einsum('kij,j->ki',MATS,v[0])
        return out.ravel()
    initial=np.zeros((25,6),complex);initial[0,0]=1
    times=np.linspace(T/10,T,61)
    sol=solve_ivp(rhs,(0,T),initial.ravel(),t_eval=times,method='DOP853',rtol=rtol,atol=atol)
    if not sol.success:raise RuntimeError(sol.message)
    v=sol.y.T.reshape(61,25,6);c=v[:,0];s=v[:,1:]
    z=c[:,1:4]/c[:,0,None]
    dz=(s[:,:,1:4]*c[:,None,0,None]-c[:,None,1:4]*s[:,:,0,None])/c[:,None,0,None]**2
    cj=dz.transpose(0,2,1).reshape(-1,24)
    return np.vstack([cj.real,cj.imag]),z,{'nfev':sol.nfev,'norm_error':float(np.max(abs(np.sum(abs(c)**2,axis=1)-1))), 'rtol':rtol,'atol':atol}

def fisher(j,indices):
    target=j[:,TARGET];nuisance_indices=[k for k in indices if k!=TARGET]
    jj=j[:,indices];norms=np.linalg.norm(jj,axis=0);normalized=jj/norms
    singular=np.linalg.svd(normalized,compute_uv=False)
    full_threshold=max(normalized.shape)*np.finfo(float).eps*singular[0]
    n=j[:,nuisance_indices];n=n/np.linalg.norm(n,axis=0)
    u,sv,_=np.linalg.svd(n,full_matrices=False)
    threshold=max(n.shape)*np.finfo(float).eps*sv[0]
    rank=int(np.sum(sv>threshold))
    r=target-u[:,:rank]@(u[:,:rank].T@target)
    fixed=float(target@target);eff=float(r@r)
    threshold_checks={}
    for multiplier in [1,10,100,1000]:
        k=int(np.sum(sv>threshold*multiplier))
        rr=target-u[:,:k]@(u[:,:k].T@target)
        threshold_checks[str(multiplier)]={'nuisance_rank':k,'sd_inflation':float(np.sqrt(fixed/(rr@rr)))}
    return {'parameters':[LABELS[k] for k in indices], 'target':LABELS[TARGET],
        'nuisance':[LABELS[k] for k in nuisance_indices], 'J_shape':list(jj.shape),
        'normalized_singular_values':singular.tolist(), 'normalized_rank':int(np.sum(singular>full_threshold)),
        'normalized_rank_threshold':float(full_threshold), 'normalized_condition_number':float(singular[0]/singular[-1]),
        'nuisance_singular_values':sv.tolist(),'nuisance_rank':rank,'nuisance_rank_threshold':float(threshold),
        'fixed_information_sigma1':fixed,'efficient_information_sigma1':eff,
        'efficient_over_fixed':eff/fixed,'sd_inflation':float(np.sqrt(fixed/eff)),
        'efficient_sd_per_unit_sigma':float(1/np.sqrt(eff)), 'threshold_checks':threshold_checks}

def polynomial(z,T,p,j):
    # Local coefficients from z_n=sum a_k t^k, degrees n..n+p.
    # Equal independent component noise; exact coefficient covariance of LS.
    x=np.linspace(.1,1,61);ratios={};variance=0
    cj=(j[:183]+1j*j[183:]).reshape(61,3,24)
    response=np.zeros(24)
    for n in [2,3]:
        powers=np.arange(n,n+p+1)
        pinv=np.linalg.pinv(x[:,None]**powers[None,:])
        scales=T**(-powers)
        coef=(pinv@z[:,n-1])*scales
        cov=(pinv@pinv.T)*scales[:,None]*scales[None,:]
        a,b=coef[:2];ratios[n]=(n+1)*b/a
        gradient=np.array([-(n+1)*b/a**2,(n+1)/a])
        variance+=float(np.real(gradient.conj()@cov[:2,:2]@gradient))
        coefficient_sensitivity=(pinv@cj[:,n-1,:])*scales[:,None]
        response+=(1 if n==2 else -1)*np.imag(gradient@coefficient_sensitivity[:2])
    energy=float(-np.imag(ratios[3]-ratios[2]))
    return {'degree_extra':p,'noiseless_energy_estimate':energy,'true_energy':float(E[3]-E[0]),
        'signed_noiseless_bias':energy-float(E[3]-E[0]),'delta_sd_per_unit_sigma':math.sqrt(variance),
        'noiseless_estimator_parameter_response':dict(zip(LABELS,response.tolist())),
        'target_parameter_response':float(response[TARGET]),
        'maximum_absolute_nuisance_response':float(np.max(abs(np.delete(response,TARGET)))),
        'interpretation':'Local linear noise propagation around noiseless finite-window fit; not a population SD of the unregularized Gaussian ratio.'}

def main():
    windows=[]
    for T in [.12,.24,.48]:
        j,z,solver=propagate(T,1e-12,1e-15)
        jt,zt,solvert=propagate(T,1e-13,1e-16)
        entries={}
        for name,idx in SETS.items():
            entry=fisher(j,idx);tight=fisher(jt,idx)
            entry['tight_tolerance']={'sd_inflation':tight['sd_inflation'], 'normalized_rank':tight['normalized_rank'],
                'nuisance_rank':tight['nuisance_rank'], 'smallest_normalized_singular_value':tight['normalized_singular_values'][-1],
                'relative_eff_information_change':abs(entry['efficient_information_sigma1']/tight['efficient_information_sigma1']-1)}
            entries[name]=entry
        poly=[polynomial(z,T,p,j) for p in [2,3]]
        for row in poly:
            row['delta_sd_sigma1e8']=row['delta_sd_per_unit_sigma']*1e-8
            row['delta_sd_over_efficient_bound']={name:row['delta_sd_per_unit_sigma']/entry['efficient_sd_per_unit_sigma'] for name,entry in entries.items()}
        windows.append({'T':T,'solver':solver,'tight_solver':solvert,'max_coordinate_tolerance_change':float(np.max(abs(z-zt))), 'fisher':entries,'polynomial':poly})
    out={'parameter_convention':'d0 value; d1 first derivative; d2 second derivative multiplying t²/2',
         'fixed_for_all_sets':'E0 and its first/second derivatives; E5,g4 and their first/second derivatives; all unlisted coefficients',
         'noise_model':'independent equal Gaussian noise in each Re/Im z1,z2,z3 at 61 times [T/10,T]',
         'observations':366, 'target':'constant shift E3(0), E0 fixed',
         'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'windows':windows}
    _output_path(ROOT / 'extended_fisher.json').write_text(json.dumps(_record_environment(out),indent=2)+'\n')
    for w in windows:
        print('T',w['T'])
        for name,e in w['fisher'].items():print(name,'rank',e['normalized_rank'],'inflation',e['sd_inflation'],'smin',e['normalized_singular_values'][-1],'eff tolerance relative',e['tight_tolerance']['relative_eff_information_change'])
        print('polynomial',[(r['degree_extra'],r['signed_noiseless_bias'],r['delta_sd_sigma1e8']) for r in w['polynomial']])

if __name__=='__main__':main()
