#!/usr/bin/env python3
"""Independent fixed/efficient Fisher check for the six-level quadratic control.

Run: python fisher_check.py --output fisher_check.json
Unknown instantaneous parameters: E1,E2,E3,g0,g1,g2. E0, E4,E5,
g3,g4 and all first/second time derivatives are fixed. Quadratic laws
use coefficient 1/2 times the supplied second derivative. Observations
are Re/Im(z1,z2,z3) at 61 equally spaced times in [T/10,T].
Information assumes independent equal-variance Gaussian component noise;
the variance cancels in the reported ratios. E3 is the target parameter.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import argparse
import json
import platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp

E = np.array([.12,.37,1.91,.82,3.44,1.27])
ED = np.array([.07,-.13,.05,.19,-.11,.03])
EDD = np.array([.02,-.01,.04,-.03,.01,.05])
G = np.array([.73,1.11,.58,.94,.67])
GD = np.array([-.19,.08,.14,-.05,.09])
GDD = np.array([.06,-.02,.03,.04,-.01])
PARAMETERS = ['E1','E2','E3','g0','g1','g2']
BASIS = np.zeros((6,6,6))
for k in range(3):
    BASIS[k,k+1,k+1] = 1
    BASIS[k+3,k,k+1] = BASIS[k+3,k+1,k] = 1

def rhs(t, y):
    c = y.reshape(7,6)
    diagonal = E + ED*t + .5*EDD*t*t
    off = G + GD*t + .5*GDD*t*t
    h = np.diag(diagonal) + np.diag(off,1) + np.diag(off,-1)
    out = -1j*c@h.T
    out[1:] += -1j*np.einsum('kij,j->ki', BASIS, c[0])
    return out.ravel()

def evaluate(t_end, rtol, atol):
    initial = np.zeros((7,6), dtype=complex)
    initial[0,0] = 1
    solution = solve_ivp(rhs, (0,t_end), initial.ravel(),
                         t_eval=np.linspace(t_end/10,t_end,61),
                         method='DOP853', rtol=rtol, atol=atol)
    if not solution.success:
        raise RuntimeError(solution.message)
    state = solution.y.T.reshape(61,7,6)
    c = state[:,0,:]
    sens = state[:,1:,:]
    z_sens = (sens[:,:,1:4]*c[:,None,0,None]
              - c[:,None,1:4]*sens[:,:,0,None])/c[:,None,0,None]**2
    # Rows: times then coordinate components; columns: listed parameters.
    complex_j = z_sens.transpose(0,2,1).reshape(-1,6)
    j = np.vstack((complex_j.real, complex_j.imag))
    target = j[:,2]
    nuisance = np.delete(j,2,axis=1)
    # Projection rather than subtraction of nearly equal Fisher entries.
    column_norms = np.linalg.norm(nuisance,axis=0)
    normalized_nuisance = nuisance/column_norms
    coefficients = np.linalg.lstsq(normalized_nuisance,target,rcond=None)[0]
    residual = target-normalized_nuisance@coefficients
    fixed = float(target@target)
    efficient = float(residual@residual)
    singular = np.linalg.svd(j,compute_uv=False)
    normalized_singular = np.linalg.svd(j/np.linalg.norm(j,axis=0),compute_uv=False)
    nuisance_singular = np.linalg.svd(normalized_nuisance,compute_uv=False)
    rank_tol = float(max(j.shape)*np.finfo(float).eps*singular[0])
    ratio = efficient/fixed
    return {
        'T': t_end, 'component_noise_sigma': 1.0,
        'fixed_information': fixed, 'efficient_information': efficient,
        'efficient_over_fixed': ratio, 'sd_inflation': ratio**-.5,
        'J_shape': list(j.shape), 'rank': int(np.sum(singular>rank_tol)),
        'rank_threshold': rank_tol, 'singular_values': singular.tolist(),
        'condition_number': float(singular[0]/singular[-1]),
        'column_normalized_singular_values': normalized_singular.tolist(),
        'column_normalized_condition_number': float(normalized_singular[0]/normalized_singular[-1]),
        'normalized_nuisance_singular_values': nuisance_singular.tolist(),
        'normalized_nuisance_rank': int(np.linalg.matrix_rank(normalized_nuisance)),
        'target_column_correlations': ((j.T@target)/(np.linalg.norm(j,axis=0)*np.linalg.norm(target))).tolist(),
        'minimum_reference_population': float(np.min(abs(c[:,0])**2)),
        'maximum_norm_error': float(np.max(abs(np.sum(abs(c)**2,axis=1)-1))),
        'solver': {'method':'DOP853','rtol':rtol,'atol':atol,'nfev':solution.nfev}
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    results = []
    for t_end in [.12,.24,.48]:
        base = evaluate(t_end,1e-12,1e-14)
        tighter = evaluate(t_end,1e-13,1e-15)
        base['tolerance_check'] = {
            'rtol':1e-13,'atol':1e-15,
            'efficient_over_fixed':tighter['efficient_over_fixed'],
            'absolute_ratio_difference':abs(base['efficient_over_fixed']-tighter['efficient_over_fixed']),
            'relative_fixed_information_difference':abs(base['fixed_information']/tighter['fixed_information']-1),
            'relative_efficient_information_difference':abs(base['efficient_information']/tighter['efficient_information']-1)
        }
        results.append(base)
    report = {
        'source':'six-level quadratic control parameters stated in the accompanying manuscript', 'parameter_order':PARAMETERS,
        'target':'E3-E0 (E0 fixed)', 'nuisance':['E1','E2','g0','g1','g2'],
        'fixed':'E0,E4,E5,g3,g4 and all first and second time derivatives',
        'sampling':'61 uniform times in [T/10,T], z1,z2,z3 real and imaginary components',
        'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
        'results':results
    }
    _output_path(args.output).write_text(json.dumps(_record_environment(report),indent=2)+'\n')
    print(json.dumps(_record_environment(report),indent=2))

if __name__ == '__main__':
    main()
