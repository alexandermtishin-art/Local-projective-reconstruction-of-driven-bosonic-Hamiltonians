#!/usr/bin/env python3
"""High-precision independent power-series check of extended Fisher projection.

All decimal control coefficients are parsed exactly in mpmath. State and
parameter sensitivities are Taylor-expanded by the Schrödinger recurrence.
The covariance-weighted Euclidean projection is computed at high precision;
normalization changes only basis of nuisance span. No truncated singular mode
is silently removed. Runs two precision/series-order combinations.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json, math, time
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'dependencies'))
import mpmath as mp
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from extended_fisher import PARAMS,LABELS,SETS,TARGET

ROOT=Path(__file__).resolve().parent
TABLE=[
 ['.12','.37','1.91','.82','3.44','1.27'],
 ['.07','-.13','.05','.19','-.11','.03'],
 ['.02','-.01','.04','-.03','.01','.05']]
OFF=[['.73','1.11','.58','.94','.67'],['-.19','.08','.14','-.05','.09'],['.06','-.02','.03','.04','-.01']]

def run(dps,order):
    mp.mp.dps=dps
    h=[]
    for k in range(3):
        a=mp.matrix(6)
        for j in range(6):a[j,j]=mp.mpf(TABLE[k][j])/math.factorial(k)
        for j in range(5):a[j,j+1]=a[j+1,j]=mp.mpf(OFF[k][j])/math.factorial(k)
        h.append(a)
    c=[mp.matrix(6,25)];c[0][0,0]=1
    for k in range(order):
        term=mp.matrix(6,25)
        for q in range(min(k,2)+1):term+=h[q]*c[k-q]
        for col,(kind,j,q) in enumerate(PARAMS,1):
            if k<q:continue
            if kind=='E':term[j,col]+=c[k-q][j,0]/math.factorial(q)
            else:
                term[j,col]+=c[k-q][j+1,0]/math.factorial(q)
                term[j+1,col]+=c[k-q][j,0]/math.factorial(q)
        c.append(term*(-mp.j/(k+1)))
    rows=[]
    for ts in ['.12','.24','.48']:
        T=mp.mpf(ts);j=mp.matrix(366,24)
        for k in range(61):
            t=T*(mp.mpf('.1')+mp.mpf('.9')*k/60)
            v=c[-1].copy()
            for coefficient in c[-2::-1]:v=v*t+coefficient
            for n in range(1,4):
                for col in range(24):
                    dz=(v[n,col+1]*v[0,0]-v[n,0]*v[0,col+1])/v[0,0]**2
                    r=k*3+n-1;j[r,col]=mp.re(dz);j[r+183,col]=mp.im(dz)
        entries={}
        target=j[:,TARGET];fixed=(target.T*target)[0]
        for name,idx in SETS.items():
            a=mp.matrix(366,len(idx))
            for p,col in enumerate(idx):
                v=j[:,col];norm=mp.sqrt((v.T*v)[0]);a[:,p]=v/norm
            gram=a.T*a;vals,_=mp.eigsy(gram)
            singular=[mp.sqrt(vals[k]) for k in range(len(idx)-1,-1,-1)]
            nuis=[k for k in idx if k!=TARGET]
            n=mp.matrix(366,len(nuis))
            for p,col in enumerate(nuis):
                v=j[:,col];n[:,p]=v/mp.sqrt((v.T*v)[0])
            coef=mp.lu_solve(n.T*n,n.T*target)
            residual=target-n*coef;eff=(residual.T*residual)[0]
            entries[name]={'parameters':[LABELS[k] for k in idx],
               'efficient_over_fixed':mp.nstr(eff/fixed,35),'sd_inflation':mp.nstr(mp.sqrt(fixed/eff),35),
               'efficient_sd_per_unit_sigma':mp.nstr(1/mp.sqrt(eff),35),
               'normalized_singular_values':[mp.nstr(x,35) for x in singular],
               'smallest_singular_value':mp.nstr(singular[-1],35),
               'normalized_full_rank':all(x>0 for x in singular),
               'double_precision_rank_threshold':mp.nstr(366*mp.mpf(str(2.220446049250313e-16))*singular[0],20)}
        rows.append({'T':float(T),'fisher':entries})
        print('dps',dps,'order',order,'T',ts,[(name,entry['sd_inflation']) for name,entry in entries.items()],flush=True)
    return {'dps':dps,'Taylor_order':order,'windows':rows}

if __name__=='__main__':
    start=time.time();runs=[run(50,50),run(70,70)]
    differences=[]
    for a,b in zip(runs[0]['windows'],runs[1]['windows']):
        differences.append({'T':a['T'],'relative_inflation_changes':{name:float(abs(mp.mpf(a['fisher'][name]['sd_inflation'])/mp.mpf(b['fisher'][name]['sd_inflation'])-1)) for name in SETS}})
    result={'description':__doc__,'runs':runs,'stability':differences,'elapsed_seconds':time.time()-start}
    _output_path(ROOT / 'high_precision_fisher.json').write_text(json.dumps(_record_environment(result),indent=2)+'\n')
    print('stability',differences,flush=True)
