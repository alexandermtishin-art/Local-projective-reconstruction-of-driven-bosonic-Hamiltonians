import json
from pathlib import Path
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter

ROOT = Path(__file__).resolve().parent
import argparse
parser=argparse.ArgumentParser(description='Render explicitly selected stored data.')
parser.add_argument('--input-path',type=Path,default=ROOT)
args=parser.parse_args()
INPUT=args.input_path
OUTPUT=ROOT/'regenerated'
OUTPUT.mkdir(exist_ok=True)
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)
colors = ["#0B6FA0", "#BB6A12", "#853D78"]


def save(fig, name):
    fig.savefig(OUTPUT / (name + ".png"), dpi=350, bbox_inches="tight")
    fig.savefig(OUTPUT / (name + ".pdf"), bbox_inches="tight")
    plt.close(fig)


r = json.loads((INPUT / "jacobi_window_controls_results.json").read_text())["finite_window"]
raw = np.load(INPUT / "jacobi_window_trials.npz")
truth = np.asarray(r["truth"])
Ts = [0.015, 0.03, 0.06, 0.12, 0.24, 0.48, 0.96]
fig, ax = plt.subplots(figsize=(6.8, 3.7), layout="constrained")
for sigma, col, mk, lab in zip(
    ["1e-10", "1e-08", "1e-06"],
    colors,
    ["o", "s", "^"],
    [r"$\sigma=10^{-10}$", r"$\sigma=10^{-8}$", r"$\sigma=10^{-6}$"],
):
    q = np.array(
        [
            np.quantile(abs(raw[f"T{i}_p2_s{sigma}"][:, 1, 2] - truth[1, 2]), [0.25, 0.5, 0.75])
            for i in range(7)
        ]
    )
    ax.fill_between(Ts, q[:, 0], q[:, 2], color=col, alpha=0.15, lw=0)
    ax.loglog(Ts, q[:, 1], color=col, marker=mk, ms=4.5, lw=1.6, label=lab)
rows = [x for x in r["rows"] if x["sigma"] == 1e-8 and x["extra_orders"] == 2]
ax.loglog(
    Ts,
    [abs(x["bias"][1][2]) for x in rows],
    color="#333333",
    ls="--",
    lw=1.4,
    label="Absolute noiseless error",
)
ax.axhline(0.07, color="#777777", ls=":", lw=1, label="10% of true offset")
ax.set(xlabel="Window end T", ylabel=r"Absolute error in $E_3-E_0$ ($\hbar=1$)")
ax.set_xticks(Ts)
ax.set_xticklabels([str(t) for t in Ts])
ax.xaxis.set_minor_formatter(NullFormatter())
ax.grid(alpha=0.18)
ax.legend(frameon=False, fontsize=9, loc="upper right")
save(fig, "jacobi_window_errors")

# Provenance sidecar identifies every selected plotted input and renderer.
import hashlib, platform
import scipy
input_names = ['jacobi_window_trials.npz', 'jacobi_window_controls_results.json']
provenance = {
    "script": {"path": str(Path(__file__).resolve().relative_to(ROOT.parent)), "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
    "inputs": [{"path": str(Path(__file__).parent.name / name) if INPUT.resolve() == ROOT.resolve() else str(Path(__file__).parent.name / "regenerated" / name) if INPUT.resolve() == (ROOT / "regenerated").resolve() else name, "sha256": hashlib.sha256((INPUT / name).read_bytes()).hexdigest()} for name in input_names],
    "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "matplotlib": matplotlib.__version__},
    "outputs": ['jacobi_window_errors.png', 'jacobi_window_errors.pdf'],
}
(OUTPUT / 'jacobi_window_errors_provenance.json').write_text(json.dumps(provenance, indent=2) + "\n")
