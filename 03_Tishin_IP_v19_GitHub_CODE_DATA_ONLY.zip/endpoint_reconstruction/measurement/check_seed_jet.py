"""Exact check of the seeded-jet identities with Taylor jets (no windows, no noise)."""

import sys, math
from pathlib import Path
import numpy as np

R = Path(__file__).resolve().parent
sys.path.insert(0, str(R.parent / "jacobi_control"))
from jacobi_window_controls import E, ED, EDD, G, GD, GDD, jets

hs = [
    np.diag(E) + np.diag(G, 1) + np.diag(G, -1),
    np.diag(ED) + np.diag(GD, 1) + np.diag(GD, -1),
    np.diag(EDD) + np.diag(GDD, 1) + np.diag(GDD, -1),
]


def zjet(eps, phi, order=6):
    # Taylor coefficients of c(t) from psi(0), then series division z_n = c_n / c_0
    v0 = np.zeros(6, complex)
    v0[0] = np.sqrt(1 - eps**2)
    v0[1] = eps * np.exp(1j * phi)
    v = [v0]
    for m in range(order):
        v.append(-1j * sum(math.comb(m, k) * hs[k] @ v[m - k] for k in range(min(m, 2) + 1)))
    c = np.array([v[k] / math.factorial(k) for k in range(order + 1)])  # c[k, level]
    z = np.zeros((6, order + 1), complex)
    for n in range(6):
        for k in range(order + 1):
            z[n, k] = (c[k, n] - sum(c[j, 0] * z[n, k - j] for j in range(1, k + 1))) / c[0, 0]
    return z


e0 = E - E[0]
for eps, phi in [(1e-2, 0.3), (0.2, 2.1)]:
    z = zjet(eps, phi)
    s = eps * np.exp(1j * phi) / np.sqrt(1 - eps**2)
    worst = 0
    for n in range(1, 5):
        al = (-1j) ** (n - 1) * np.prod(G[1:n]) / math.factorial(n - 1)
        a = (-1j) ** n * np.prod(G[:n]) / math.factorial(n)
        P = -1j * e0[1]
        for k in range(2, n + 1):
            P = P + (k - 1) * GD[k - 1] / G[k - 1] - 1j * e0[k]
        beta = al * P / n
        worst = max(
            worst, abs(z[n, n - 1] - s * al), abs(z[n, n] - (a + s * beta + 1j * s * s * G[0] * al))
        )
    print(eps, phi, "max identity error", worst)
