import json
from pathlib import Path
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from matplotlib.lines import Line2D

R = Path(__file__).resolve().parent
import argparse
parser=argparse.ArgumentParser(description='Render explicitly selected stored data.')
parser.add_argument('--input-path',type=Path,default=R)
args=parser.parse_args()
INPUT=args.input_path
OUTPUT=R/'regenerated'
OUTPUT.mkdir(exist_ok=True)
d = json.loads((INPUT / "measurement_preparation_results.json").read_text())
p = json.loads((INPUT / "prep_aware_results.json").read_text())
raw = np.load(INPUT / "measurement_trials.npz")
truth = np.asarray(d["truth"])
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)
colors = ["#0B6FA0", "#BB6A12", "#853D78"]
marks = ["o", "s", "^"]
f, ax = plt.subplots(1, 2, figsize=(10.4, 3.8), layout="constrained")
Ts = [0.12, 0.24, 0.48]
for S, c, m in zip([8, 10, 12], colors, marks):
    q = np.array(
        [
            np.quantile(abs(raw[f"shot_T{i}_S{10**S}"][:, 1, 2] - truth[1, 2]), [0.25, 0.5, 0.75])
            for i in range(3)
        ]
    )
    ax[0].fill_between(Ts, q[:, 0], q[:, 2], color=c, alpha=0.15, lw=0)
    ax[0].loglog(Ts, q[:, 1], color=c, marker=m, ms=4.5, lw=1.6, label=rf"$S=10^{{{S}}}$")
ax[0].axhline(0.07, color="#777777", ls=":", lw=1, label="10% of true offset")
ax[0].set_ylabel(r"Absolute error in $E_3-E_0$ ($\hbar=1$)")
ax[0].set_xticks(Ts)
ax[0].set_xticklabels(["0.12", "0.24", "0.48"])
ax[0].legend(frameon=False, fontsize=9, loc="upper right")
ts = [0.015, 0.03, 0.06, 0.12, 0.24, 0.48]
for eps, c, m in zip([1e-6, 1e-4, 1e-2], colors, marks):
    for est, ls, mf in [("endpoint", "-", c), ("free", "--", "white")]:
        yy = [
            max(
                abs(r[est + "_additional_error"][1][2])
                for r in p["preparation_rows"]
                if r["epsilon"] == eps and r["T"] == T
            )
            for T in ts
        ]
        ax[1].loglog(ts, yy, color=c, ls=ls, marker=m, ms=4.5, mfc=mf, lw=1.5)
ax[1].set_ylabel(r"Max. additional error in $E_3-E_0$ ($\hbar=1$)")
ax[1].set_xticks(ts)
ax[1].set_xticklabels([str(t) for t in ts])
h = [
    Line2D([], [], color=c, marker=m, ls="-", label=rf"$\epsilon=10^{{{e}}}$")
    for c, m, e in zip(colors, marks, [-6, -4, -2])
]
h += [
    Line2D([], [], color="#444444", ls="-", label="Endpoint estimator"),
    Line2D([], [], color="#444444", ls="--", marker="o", mfc="white", label="Preparation-aware"),
]
ax[1].legend(handles=h, frameon=False, fontsize=8, loc="upper left", bbox_to_anchor=(1.01, 1.0))
for i, a in enumerate(ax):
    a.set_xlabel("Window end T")
    a.grid(alpha=0.15)
    a.xaxis.set_minor_formatter(NullFormatter())
    a.set_title("ab"[i], loc="left", fontweight="bold", fontsize=11)
f.savefig(OUTPUT / "measurement_preparation_controls.png", dpi=350)
f.savefig(OUTPUT / "measurement_preparation_controls.pdf")

# Provenance sidecar identifies every selected plotted input and renderer.
import hashlib, platform
import scipy
input_names = ['measurement_trials.npz', 'measurement_preparation_results.json', 'prep_aware_results.json']
provenance = {
    "script": {"path": str(Path(__file__).resolve().relative_to(R.parent)), "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
    "inputs": [{"path": str(Path(__file__).parent.name / name) if INPUT.resolve() == R.resolve() else str(Path(__file__).parent.name / "regenerated" / name) if INPUT.resolve() == (R / "regenerated").resolve() else name, "sha256": hashlib.sha256((INPUT / name).read_bytes()).hexdigest()} for name in input_names],
    "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "matplotlib": matplotlib.__version__},
    "outputs": ['measurement_preparation_controls.png', 'measurement_preparation_controls.pdf'],
}
(OUTPUT / 'measurement_preparation_controls_provenance.json').write_text(json.dumps(provenance, indent=2) + "\n")
