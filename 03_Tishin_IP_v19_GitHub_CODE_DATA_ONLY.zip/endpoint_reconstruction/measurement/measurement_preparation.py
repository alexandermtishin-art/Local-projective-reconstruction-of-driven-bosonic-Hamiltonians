"""Exact multinomial measurement and coherent endpoint-preparation controls.
All shots count fresh preparations; no physical experiment is claimed.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target


import sys, json, math
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "jacobi_control"))
from jacobi_window_controls import H, E, G, GD, estimate

TRUTH = np.stack([G[:3], E[1:4] - E[0], GD[:3] / G[:3]])


def state(T, eps=0.0, phase=0.0, tol=2e-13):
    y = np.zeros(6, complex)
    y[0] = np.sqrt(1 - eps**2)
    y[1] = eps * np.exp(1j * phase)
    ts = np.linspace(0.1 * T, T, 61)
    sol = solve_ivp(
        lambda t, c: -1j * H(t) @ c,
        (0, T),
        y,
        t_eval=ts,
        method="DOP853",
        rtol=tol,
        atol=tol * 1e-3,
    )
    assert sol.success
    return sol.y


def probabilities(c):
    p0 = abs(c[0]) ** 2
    pn = abs(c[1:4]) ** 2
    r = c[1:4] * c[0].conj()
    probs = np.empty((3, 2, 61, 3))
    for n in range(3):
        for a, v in enumerate([r[n].real, r[n].imag]):
            probs[n, a, :, 0] = (p0 + pn[n]) / 2 + v
            probs[n, a, :, 1] = (p0 + pn[n]) / 2 - v
            probs[n, a, :, 2] = 1 - p0 - pn[n]
    assert np.min(probs) > -1e-12
    probs = np.maximum(probs, 0)
    probs /= probs.sum(axis=-1, keepdims=True)
    return p0, probs


def sample(c, S, reps, rng):
    p0, probs = probabilities(c)
    den = rng.binomial(S, np.clip(p0, 0, 1), size=(reps, 61)) / S
    assert np.all(den > 0)
    obs = np.empty((reps, 3, 61), complex)
    for n in range(3):
        a = []
        for ax in range(2):
            counts = np.stack(
                [rng.multinomial(S, probs[n, ax, k], size=reps) for k in range(61)], axis=1
            )
            a.append((counts[:, :, 0] - counts[:, :, 1]) / (2 * S))
        obs[:, n] = (a[0] + 1j * a[1]) / den
    return obs


def delta_cov(c, S):
    p0 = abs(c[0]) ** 2
    pn = abs(c[1:4]) ** 2
    r = c[1:4] * c[0].conj()
    covs = []
    for k in range(61):
        vals = np.stack([r[:, k].real, r[:, k].imag], axis=1).reshape(-1)
        diag = np.repeat(p0[k] + pn[:, k], 2) - 4 * vals**2
        cov = np.diag(diag / (4 * S * p0[k] ** 2)) + np.outer(vals, vals) * (1 - p0[k]) / (
            S * p0[k] ** 3
        )
        covs.append(cov)
    return np.array(covs)


def main():
    rng = np.random.default_rng(25092601)
    raw = {}
    rows = []
    for ti, T in enumerate([0.12, 0.24, 0.48]):
        c = state(T)
        for S in [10**8, 10**10, 10**12]:
            obs = sample(c, S, 300, rng)
            est = estimate(obs, T, 2)
            raw[f"shot_T{ti}_S{S}"] = est
            rmse = np.sqrt(np.mean((est - TRUTH) ** 2, axis=0))
            rows.append(
                dict(
                    T=T,
                    shots_per_setting=S,
                    total_preparations=61 * 7 * S,
                    replicates=300,
                    rmse=rmse.tolist(),
                    median_abs_error=np.median(abs(est - TRUTH), axis=0).tolist(),
                    min_reference_probability=float(min(abs(c[0]) ** 2)),
                )
            )
    # Independent validation of signs, probabilities, normalization and covariance.
    c = state(0.48)
    p0, probs = probabilities(c)
    recovered = (
        probs[:, 0, :, 0] - probs[:, 0, :, 1] + 1j * (probs[:, 1, :, 0] - probs[:, 1, :, 1])
    ) / (2 * p0)
    identity = float(np.max(abs(recovered - c[1:4] / c[0])))
    obs = sample(c, 10**6, 10000, rng)
    at = 60
    v = np.stack([obs[:, :, at].real, obs[:, :, at].imag], axis=-1).reshape(10000, 6)
    empirical = np.cov(v, rowvar=False)
    pred = delta_cov(c, 10**6)[at]
    validation = dict(
        probability_identity_error=identity,
        covariance_diagonal_ratio=(empirical.diagonal() / pred.diagonal()).tolist(),
        ode_max_difference=float(np.max(abs(c - state(0.48, tol=4e-14)))),
    )
    assert identity < 1e-14 and np.max(abs(empirical.diagonal() / pred.diagonal() - 1)) < 0.08
    prep = []
    for T in [0.015, 0.03, 0.06, 0.12, 0.24, 0.48]:
        ideal = estimate((state(T)[1:4] / state(T)[0])[None], T, 2)[0]
        for eps in [1e-6, 1e-4, 1e-2]:
            for phase in [0.0, np.pi / 2, np.pi, 3 * np.pi / 2]:
                c = state(T, eps, phase)
                z = c[1:4] / c[0]
                est = estimate(z[None], T, 2)[0]
                # exact initial subtraction still does not restore endpoint derivatives
                z0 = np.zeros(3, complex)
                z0[0] = eps * np.exp(1j * phase) / np.sqrt(1 - eps**2)
                subtract = estimate((z - z0[:, None])[None], T, 2)[0]
                prep.append(
                    dict(
                        T=T,
                        epsilon=eps,
                        infidelity=eps**2,
                        phase=phase,
                        estimate=est.tolist(),
                        ideal_estimate=ideal.tolist(),
                        additional_error=(est - ideal).tolist(),
                        initial_subtraction_estimate=subtract.tolist(),
                    )
                )
    np.savez_compressed(_output_path(ROOT / "measurement_trials.npz"), provenance=np.array(json.dumps(_record_environment({"status":"regenerated","generator":Path(__file__).name}))), **raw)
    result = dict(
        seed=25092601,
        truth=TRUTH.tolist(),
        shot_trials=2700,
        measurement_rows=rows,
        validation=validation,
        preparation_rows=prep,
        preparation_cases=len(prep),
        protocol="S copies in each of 2L quadrature settings and S separate copies for p0; L=3,K=61; orthogonal three-outcome measurements",
    )
    _output_path(ROOT / "measurement_preparation_results.json").write_text(json.dumps(_record_environment(result), indent=2))
    print("VALIDATION", validation)
    for r in rows:
        print("SHOT", r["T"], r["shots_per_setting"], r["rmse"][1][2])
    for T in [0.03, 0.12, 0.24]:
        for eps in [1e-6, 1e-4, 0.01]:
            rr = [r for r in prep if r["T"] == T and r["epsilon"] == eps]
            print(
                "PREP",
                T,
                eps,
                "max additional E3",
                max(abs(r["additional_error"][1][2]) for r in rr),
                "max additional g0",
                max(abs(r["additional_error"][0][0]) for r in rr),
            )


if __name__ == "__main__":
    main()
