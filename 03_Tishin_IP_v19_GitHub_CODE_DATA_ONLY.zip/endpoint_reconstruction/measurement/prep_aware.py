"""Preparation-aware local estimator for a measured coherent admixture on level 1.

Exact seeded-jet identities (verified in check_seed_jet.py), with sigma = z_1(0):
  coefficient of t^(n-1) in z_n : sigma * alpha'_n
  coefficient of t^n     in z_n : a_n + sigma*beta'_n + i*sigma^2*g_0*alpha'_n
The estimator fits degrees n-1..n+1+p, removes the seeded part of the t^n
coefficient with the current layer estimates (fixed-point iteration), and applies
the endpoint formulas (10)-(12). The t^(n+1) coefficient is not corrected.
"""

import math
import numpy as np


def fit_coeffs(z, T, sigma0, extra=2):
    """Return k_n (t^n) and k_{n+1} (t^{n+1}) for n=1..3; z shape (rep, 3, time)."""
    x = np.linspace(0.1, 1, z.shape[-1])
    kn = []
    kn1 = []
    for n in range(1, 4):
        lo = n if n == 1 else n - 1  # level 1: constant is the measured sigma0
        data = z[:, n - 1] - (sigma0 if n == 1 else 0)
        mat = x[:, None] ** np.arange(lo, n + extra + 1)[None, :]
        co = data @ np.linalg.pinv(mat).T
        j = n - lo
        kn.append(co[:, j] / T**n)
        kn1.append(co[:, j + 1] / T ** (n + 1))
    return np.array(kn), np.array(kn1)  # shape (3, rep)


def layers(a, b):
    """Endpoint formulas from a_n, b_n (Taylor coefficients)."""
    A = [np.ones(a.shape[1], complex)]
    Rr = [np.zeros(a.shape[1], complex)]
    for n in range(1, 4):
        A.append(math.factorial(n) * a[n - 1])
        Rr.append((n + 1) * b[n - 1] / a[n - 1])
    g = np.array([abs(A[n] / A[n - 1]) for n in range(1, 4)])
    d = np.array([Rr[n] - Rr[n - 1] for n in range(1, 4)])
    return g, -d.imag, d.real / np.arange(1, 4)[:, None]


def estimate(z, T, sigma0, extra=2, iters=6, correct=True):
    kn, kn1 = fit_coeffs(z, T, sigma0, extra)
    a = kn.copy()
    for _ in range(iters if correct else 1):
        g, e, r = layers(a, kn1)
        if not correct:
            break
        P = -1j * e[0]
        new = []
        for n in range(1, 4):
            if n > 1:
                P = P + (n - 1) * r[n - 1] * 1 - 1j * e[n - 1]  # r[n-1] = gdot_{n-1}/g_{n-1}
            al = (-1j) ** (n - 1) * np.prod(g[1:n], axis=0) / math.factorial(n - 1)
            beta = al * P / n
            new.append(kn[n - 1] - sigma0 * beta - 1j * sigma0**2 * g[0] * al)
        a = np.array(new)
    g, e, r = layers(a, kn1)
    return np.stack([g.T, e.T, r.T], axis=1)


def estimate_subtract(z, T, sigma0, extra=2, iters=8, init=None):
    """Variant with the specified fit design (degrees n..n+extra): the seeded leading
    term sigma*alpha'_n t^(n-1), evaluated with the current coupling estimates, is
    subtracted before fitting; the t^n coefficient is corrected as in estimate()."""
    x = np.linspace(0.1, 1, z.shape[-1])
    t = x * T
    if init is None:
        init = estimate(z, T, sigma0, extra)
    g = init[:, 0, :].T
    for _ in range(iters):
        kn = []
        kn1 = []
        for n in range(1, 4):
            if n == 1:
                lead = sigma0 * np.ones((z.shape[0], 1))
            elif g is None:
                lead = 0.0
            else:
                al = (-1j) ** (n - 1) * np.prod(g[1:n], axis=0) / math.factorial(n - 1)
                lead = (sigma0 * al)[:, None] * t[None, :] ** (n - 1)
            mat = x[:, None] ** np.arange(n, n + extra + 1)[None, :]
            co = (z[:, n - 1] - lead) @ np.linalg.pinv(mat).T
            kn.append(co[:, 0] / T**n)
            kn1.append(co[:, 1] / T ** (n + 1))
        kn = np.array(kn)
        kn1 = np.array(kn1)
        a = kn.copy()
        for _ in range(4):
            g, e, r = layers(a, kn1)
            P = -1j * e[0]
            new = []
            for n in range(1, 4):
                if n > 1:
                    P = P + (n - 1) * r[n - 1] - 1j * e[n - 1]
                al = (-1j) ** (n - 1) * np.prod(g[1:n], axis=0) / math.factorial(n - 1)
                new.append(kn[n - 1] - sigma0 * al * P / n - 1j * sigma0**2 * g[0] * al)
            a = np.array(new)
        g, e, r = layers(a, kn1)
    return np.stack([g.T, e.T, r.T], axis=1)
