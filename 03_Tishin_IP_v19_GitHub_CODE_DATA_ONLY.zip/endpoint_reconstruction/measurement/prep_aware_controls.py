"""Preparation-aware controls: 72 noiseless cases and a noise-cost comparison.

Estimators (all use the measured initial coordinate sigma0 = z_1(0)):
  endpoint   : endpoint local polynomial estimator, degrees n..n+2 (reference)
  free       : prep_aware.estimate, degrees n-1..n+2 plus exact t^n correction
  subtract   : prep_aware.estimate_subtract, specified degrees n..n+2 after
               subtracting the predicted seeded term sigma0*alpha'_n t^(n-1)
Additional error is measured against each estimator applied to perfectly
prepared data at the same window.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target


import sys, json
from pathlib import Path
import numpy as np

R = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
sys.path.insert(0, str(R.parent / "jacobi_control"))
import measurement_preparation as mp
from jacobi_window_controls import estimate as endpoint_est
import prep_aware as pa

EST = {
    "endpoint": lambda z, T, s: endpoint_est(z, T, 2),
    "free": lambda z, T, s: pa.estimate(z, T, s),
    "subtract": lambda z, T, s: pa.estimate_subtract(z, T, s),
}


def main():
    rows = []
    for T in [0.015, 0.03, 0.06, 0.12, 0.24, 0.48]:
        c = mp.state(T)
        z0 = (c[1:4] / c[0])[None]
        ideal = {k: f(z0, T, 0.0)[0] for k, f in EST.items()}
        for eps in [1e-6, 1e-4, 1e-2]:
            for phase in [0.0, np.pi / 2, np.pi, 3 * np.pi / 2]:
                c = mp.state(T, eps, phase)
                z = (c[1:4] / c[0])[None]
                s0 = eps * np.exp(1j * phase) / np.sqrt(1 - eps**2)
                row = dict(T=T, epsilon=eps, phase=phase, seeded_scale=3 * eps / (mp.G[0] * T))
                for k, f in EST.items():
                    est = f(z, T, s0)[0]
                    row[k + "_additional_error"] = (est - ideal[k]).tolist()
                    row[k + "_ideal_bias"] = (ideal[k] - mp.TRUTH).tolist()
                rows.append(row)
    # noise cost: Gaussian coordinate noise, 400 realizations, phase 0
    rng = np.random.default_rng(25092602)
    noise = []
    for sig in [1e-8, 5e-7]:
        for T in [0.12, 0.24, 0.48]:
            for eps in [0.0, 1e-4]:
                c = mp.state(T, eps, 0.0)
                z = (c[1:4] / c[0])[None]
                s0 = eps / np.sqrt(1 - eps**2)
                zz = z + sig * (rng.normal(size=(400, 3, 61)) + 1j * rng.normal(size=(400, 3, 61)))
                for k, f in EST.items():
                    e = np.abs(f(zz, T, s0)[:, 1, 2] - mp.TRUTH[1, 2])
                    noise.append(
                        dict(
                            sigma=sig,
                            T=T,
                            epsilon=eps,
                            estimator=k,
                            median_abs_error_E3=float(np.median(e)),
                            q25=float(np.quantile(e, 0.25)),
                            q75=float(np.quantile(e, 0.75)),
                        )
                    )
    out = dict(
        description=__doc__,
        preparation_rows=rows,
        noise_rows=noise,
        seed=25092602,
        truth=mp.TRUTH.tolist(),
    )
    _output_path(R / "prep_aware_results.json").write_text(json.dumps(_record_environment(out), indent=2))
    for eps in [1e-6, 1e-4, 1e-2]:
        for k in EST:
            m = [
                max(
                    abs(r[k + "_additional_error"][1][2])
                    for r in rows
                    if r["epsilon"] == eps and r["T"] == T
                )
                for T in [0.015, 0.03, 0.06, 0.12, 0.24, 0.48]
            ]
            print(f"eps={eps:.0e} {k:9s}", " ".join(f"{x:.3g}" for x in m))
    for r in noise:
        print(r["sigma"], r["T"], r["epsilon"], r["estimator"], round(r["median_abs_error_E3"], 5))


if __name__ == "__main__":
    main()
