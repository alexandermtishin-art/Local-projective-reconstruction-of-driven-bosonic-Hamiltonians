# Prepared local controls and finite-window diagnostics

Run `python preparations/verify_access.py`, `python noise/verify_affine_noise.py`, and `python bounds/certified_bounds.py` from this directory. Requirements: numpy, scipy; the optional public-file audit also requires h5py and network access.

These checks verify adjacent-site jets, an affine oscillator-noise differential invariant, and conservative finite-count bounds. The resource audit summarizes stored seeded benchmark trials; it does not run new trials. Benchmarks use a finite quadratic model, known readout, and oracle covariance, and do not establish experimental readiness.

`noise/audit_orens.py` independently downloads public ORENS metadata and a raw file. Its results establish file eligibility, not a reconstructed experimental trajectory. Third-party raw data are not redistributed.
