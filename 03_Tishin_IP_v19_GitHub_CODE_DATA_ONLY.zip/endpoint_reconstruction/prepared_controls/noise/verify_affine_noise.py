"""Exact density jets with random parity-preserving Hamiltonians.
D[L]rho = LrhoL† - {L†L,rho}/2; hbar = 1.
No finite-window, SPAM, or experimental performance claim.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json
from pathlib import Path
import numpy as np
rng=np.random.default_rng(20261011)
N=16
a=np.diag(np.sqrt(np.arange(1,N)),1); number=a.conj().T@a

def dissipate(r,j):
 q=j.conj().T@j
 return j@r@j.conj().T-(q@r+r@q)/2

def trial(nonlin=False):
 H=np.zeros((N,N),complex);Hd=H.copy()
 for parity in [0,1]:
  ix=np.arange(parity,N,2);z=rng.normal(size=(len(ix),len(ix)));B=(z+z.T)/2
  if parity==0:
   B=np.diag(rng.normal(size=len(ix)))
   g=rng.uniform(.2,2,len(ix)-1);gd=rng.normal(size=len(ix)-1)
   B+=np.diag(g,1)+np.diag(g,-1)
   Hd[np.ix_(ix,ix)]=np.diag(rng.normal(size=len(ix)))+np.diag(gd,1)+np.diag(gd,-1)
  H[np.ix_(ix,ix)]=B
 loss,gain,phase=rng.uniform(0,1,3)
 jumps=[(loss,a),(gain,a.conj().T),(phase,number@number if nonlin else number)]
 def L(r):return -1j*(H@r-r@H)+sum(c*dissipate(r,j) for c,j in jumps)
 estimates=[]
 for k in [0,1,2,4]:
  i,j=2*k,2*k+2;r=np.zeros_like(H);r[i,i]=1
  d=L(r);dd=L(d)-1j*(Hd@r-r@Hd)
  R=(dd[j,i]-2*d[j,i]*d[i,i])/d[j,i]
  shift=-(loss+gain)-phase/2*((j*j-i*i)**2 if nonlin else (j-i)**2)
  expected=gd[k]/g[k]+shift-1j*(H[j,j]-H[i,i])
  estimates.append({'k':k,'R_real':float(R.real),'expected_real':float(expected.real),'error':float(abs(R-expected)),'rate_error':float(R.real-gd[k]/g[k])})
 return estimates
rows=[trial() for _ in range(200)]
nonlinear=[trial(True) for _ in range(20)]
result={'seed':20261011,'hbar':1,'dimensions':N,'trials':200,'sites':[0,2,4,8],
 'linear_max_identity_error':max(e['error'] for r in rows for e in r),
 'linear_max_shift_spread':max(np.ptp([e['rate_error'] for e in r]) for r in rows),
 'nonlinear_max_identity_error':max(e['error'] for r in nonlinear for e in r),
 'nonlinear_min_shift_spread':min(np.ptp([e['rate_error'] for e in r]) for r in nonlinear),
 'linear_rows':rows,'nonlinear_rows':nonlinear}
_output_path(Path(__file__).with_suffix('.json')).write_text(json.dumps(_record_environment(result),indent=2));print({k:v for k,v in result.items() if not k.endswith('rows')})
