"""Exact site-jet tradeoff, generic-probe counterexample, and readout-drift alias.
No experimental observations are generated or substituted here.
"""

import platform
import sys as _environment_sys
import numpy as _env_np
import scipy as _env_sp

def _record_environment(value):
    """Attach the actual generation environment, including loaded mpmath."""
    environment = {"python":platform.python_version(), "numpy":_env_np.__version__, "scipy":_env_sp.__version__}
    if "mpmath" in _environment_sys.modules:
        environment["mpmath"] = _environment_sys.modules["mpmath"].__version__
    if not isinstance(value, dict):
        value = {"rows": value}
    value["environment"] = environment
    return value

def _output_path(path):
    """Write regenerated artifacts beside, never over, the immutable archive."""
    target = path.parent / "regenerated" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    return target

import json
from pathlib import Path
import numpy as np

def matrix(parameters):
    n=(len(parameters)+2)//2
    return np.diag(np.r_[0.,parameters[:n-1]])+np.diag(parameters[n-1:],1)+np.diag(parameters[n-1:],-1)

def field(h,z):
    hz=h@z
    return -1j*(hz-z*hz[0])

def real_vector(z):
    return np.r_[z[1:].real,z[1:].imag]

def access_matrix(z):
    d=2*len(z)-2
    return np.column_stack([real_vector(field(matrix(np.eye(d)[j]),z)) for j in range(d)])

def verify_generic(rng,n,trials):
    maximum=0.;conditions=[]
    for _ in range(trials):
        amplitudes=rng.uniform(.5,1.5,n)
        c=(1j)**np.arange(n)*amplitudes
        c/=np.linalg.norm(c);z=c/c[0]
        h=matrix(np.r_[rng.normal(size=n-1),rng.uniform(.1,2,n-1)])
        hd=matrix(rng.normal(size=2*n-2))
        zd=field(h,z)
        zdd=field(hd,z)-1j*(h@zd-zd*(h@z)[0]-z*(h@zd)[0])
        a=access_matrix(z)
        fit=np.linalg.solve(a,real_vector(zd));hf=matrix(fit)
        state_term=-1j*(hf@zd-zd*(hf@z)[0]-z*(hf@zd)[0])
        fitd=np.linalg.solve(a,real_vector(zdd-state_term))
        maximum=max(maximum,float(np.max(abs(hf-h))),float(np.max(abs(matrix(fitd)-hd))))
        conditions.append(np.linalg.cond(a))
    return {'dimension':n,'trials':trials,'maximum_H_and_Hdot_error':maximum,'maximum_condition':max(conditions)}

def verify_site(rng):
    maximum=0.;cases=0
    for n in range(2,21):
        e=rng.normal(size=n);g=rng.uniform(.1,2,n-1);gd=rng.normal(size=n-1)
        h=np.diag(e)+np.diag(g,1)+np.diag(g,-1)
        hd=np.diag(rng.normal(size=n))+np.diag(gd,1)+np.diag(gd,-1)
        for k in range(n):
            c=np.eye(n)[:,k];d=-1j*h@c;dd=-1j*hd@c-h@h@c
            for j in [k-1,k+1]:
                if not 0<=j<n:continue
                wp=d[j];wpp=dd[j]-2*d[j]*d[k]
                edge=min(j,k)
                expected=-1j*gd[edge]-g[edge]*(e[j]-e[k])
                maximum=max(maximum,abs(wp+1j*g[edge]),abs(wpp-expected));cases+=1
    return {'directed_edges_tested':cases,'maximum_identity_error':float(maximum)}

def verify_drift():
    # Taylor coefficients: w=a1*t+a2*t^2; readout factor A/q.
    a1=-.58j;a2=-.58*.45/2-.14j/2
    rows=[]
    for da,dq in [(.0,.0),(.01,.0),(.0,.01),(.01,-.02)]:
        b1=a1;b2=a2+(da-dq)*a1
        observed=2*b2/b1;expected=2*a2/a1+2*(da-dq)
        rows.append({'pair_log_drift':da,'reference_log_drift':dq,'rate_shift':float((observed-2*a2/a1).real),'maximum_formula_error':float(abs(observed-expected))})
    return rows

if __name__=='__main__':
    rng=np.random.default_rng(441129)
    output={'seed':441129,'site':verify_site(rng),'generic':[verify_generic(rng,n,100) for n in [2,3,6,10,20]],'drift':verify_drift()}
    _output_path(Path(__file__).with_suffix('.json')).write_text(json.dumps(_record_environment(output),indent=2))
    print(json.dumps(_record_environment(output),indent=2))
