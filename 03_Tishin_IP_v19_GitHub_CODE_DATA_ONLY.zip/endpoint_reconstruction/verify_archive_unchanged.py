"""Compare immutable archived output hashes after any regeneration command."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'numerical_manifest.json').read_text())
for relative,digest in manifest.items():
    assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==digest, relative
print('PASS: archived files unchanged after regeneration')
