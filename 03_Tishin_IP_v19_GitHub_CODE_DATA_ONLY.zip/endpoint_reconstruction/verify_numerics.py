#!/usr/bin/env python3
"""Read-only integrity, syntax and stored-result checks; no full regeneration."""
import ast, hashlib, json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'numerical_manifest.json').read_text())
for name,digest in manifest.items():
    p=ROOT/name
    assert p.is_file(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
scripts=[p for p in ROOT.rglob('*.py') if 'dependencies' not in p.parts and 'regenerated' not in p.parts]
for p in scripts:
    ast.parse(p.read_text(),filename=str(p))
    assert '__pycache__' not in p.parts
hp=json.loads((ROOT/'fisher/high_precision_fisher.json').read_text())
for w in hp['runs'][-1]['windows']:
    for name,result in w['fisher'].items():
        assert result['normalized_full_rank']
        assert float(result['sd_inflation'])>=1
        assert 0<float(result['efficient_over_fixed'])<=1
bootstrap=json.loads((ROOT/'fisher/bootstrap_windows.json').read_text())
assert len(bootstrap['rows'])==42
assert all(row['absolute_error']['replicates']==200 for row in bootstrap['rows'])
trials=np.load(ROOT/'jacobi_control/jacobi_window_trials.npz')
assert 'provenance' in trials.files
assert json.loads(str(trials['provenance']))['status']=='archived'
keys=[k for k in trials.files if k!='provenance']
assert len(keys)==42
assert sum(trials[k].shape[0] for k in keys)==8400
print(f'PASS: {len(manifest)} numerical files, {len(scripts)} scripts parsed, 8400 stored Jacobi estimates; high-precision Fisher and bootstrap records coherent.')

loss=json.loads((ROOT/'checks/loss_alias.json').read_text())
print('Photon-loss and information diagnostics are packaged under checks/.')
