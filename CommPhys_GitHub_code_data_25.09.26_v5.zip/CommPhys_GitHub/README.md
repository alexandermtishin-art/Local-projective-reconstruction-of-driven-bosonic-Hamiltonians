# Local projective reconstruction of driven bosonic Hamiltonians — code, data and Supplementary Information

A. M. Tishin. Companion archive for the Communications Physics submission (25 September 2026).
Repository: https://github.com/alexandermtishin-art/Local-projective-reconstruction-of-driven-bosonic-Hamiltonians

## Quick start

```bash
python -m pip install -r requirements.txt
python verify_package.py      # checksums of every file + consistency of saved estimates
python run_all.py             # regenerates all results and figures (about 1 min; overwrites outputs)
python run_all.py --with-noise --workers 8   # also reruns the 540 bosonic noise fits (hours)
```

Run `run_all.py` on a copy if you want to keep the pristine files for `verify_package.py`.
All random seeds are fixed; a full rerun reproduces the stored JSON and NPZ results to rounding level.
Tested with Python 3.11 (NumPy 2.4, SciPy 1.17, Matplotlib 3.10) and with the pinned
`requirements.txt` environment (Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, Matplotlib 3.10.8).

## Map: paper item → script → data

| Paper item | Script | Output |
|---|---|---|
| Table 1, Fig. 1, arbitrary Jacobi control | `original/projective_reconstruction_hierarchy_v3_3.py`, `original/arbitrary_jacobi_control_v3_3.py` | `original/data/` |
| Fock-cutoff audit (Methods) | `original/branchwise_cutoff_convergence_v3_3.py` | `original/data/branchwise_cutoff_convergence.csv` |
| Fig. 2, Table 2, Supplementary Note 5 | `commphys_noise/noise_study.py`, `diagnostics.py` | `commphys_noise/summary.json`, `trials.jsonl`, `diagnostics.json` |
| Fig. 3, exact sharpness and QR checks | `strengthened/jacobi_strengthening.py` | `strengthened/jacobi_strengthening_results.json`, `jacobi_window_trials.npz` |
| Efficient information (Methods, Prop. 3) | `strengthened/schur_check.py` | `strengthened/schur_results.json` |
| Fig. 4a, variance check | `experimental_extension/measurement_preparation.py` | `measurement_preparation_results.json`, `measurement_trials.npz` |
| Eqs. (32)–(33) | `experimental_extension/check_seed_jet.py` | printed identity errors |
| Fig. 4b, Supplementary Notes 3–4 | `experimental_extension/prep_aware.py`, `prep_aware_controls.py` | `prep_aware_results.json` |
| Figs. 1–3 / Fig. 4 | `strengthened/figures.py` / `experimental_extension/figures_measurement.py` | `Figure_*.png`, `Figure_*.pdf` |
| Supplementary Information | — | `supplementary/Supplementary_Information.docx` |

## Notes on the calculations

- The exact reconstruction assumes a real Jacobi chain, an endpoint initial state and physical time.
- Noise models: additive Gaussian coordinate noise (Figs. 2, 3) or exact multinomial shot counts
  for the quadrature protocol (Fig. 4a); readout errors, rotation errors and decoherence are not simulated.
- The ratio estimator has no finite moments under Gaussian noise; figures report medians and
  interquartile ranges, and all individual estimates are stored.
- Preparation-aware estimators use the measured initial coordinate; the remaining error is first
  order in the admixture amplitude.
- `original/` is the unchanged v3.3 release with its own README and `SHA256SUMS.txt`.

License: MIT (see `LICENSE`).
