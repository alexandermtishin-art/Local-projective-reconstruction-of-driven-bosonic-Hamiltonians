"""Focused validation: omitted-layer alternatives, late prediction, starts."""

import json
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from scipy.optimize import least_squares
from noise_study import ROOT, TRUE, SAMPLES, BOUNDS, stack, trajectory, late_occupation


def late_row(row):
    theta = np.array(row["theta"])
    row["late_n20_steps600"] = late_occupation(theta)
    row["late_n24_steps1200"] = late_occupation(theta, n=24, steps=1200)
    return row


def null_control(T):
    ts = np.linspace(0.1 * T, T, SAMPLES)
    truth = stack(trajectory(TRUE, ts, n=12, rtol=2e-13, atol=2e-16))
    cache = {}

    def ev(p):
        if "p" not in cache or not np.array_equal(p, cache["p"]):
            z, j = trajectory(np.r_[p, 0.0], ts, sensitivity=True)
            cache.update(p=p.copy(), f=(stack(z) - truth) / 1e-6, j=j[:, :2] / 1e-6)
        return cache

    fits = []
    for start in ([0.02, 0.02], [0.05, 0.01], [-0.1, -0.1], [0.2, 0.1]):
        fits.append(
            least_squares(
                lambda p: ev(p)["f"],
                start,
                jac=lambda p: ev(p)["j"],
                bounds=(BOUNDS[0][:2], BOUNDS[1][:2]),
                x_scale=[0.05, 0.01],
                ftol=1e-11,
                xtol=1e-11,
                gtol=1e-9,
                max_nfev=100,
            )
        )
    fit = min(fits, key=lambda f: f.cost)
    theta = np.r_[fit.x, 0.0]
    dist = np.sqrt(2 * fit.cost) * 1e-6
    return dict(
        T=T,
        theta=theta.tolist(),
        raw_rms=dist / np.sqrt(6 * SAMPLES),
        euclidean_distance=dist,
        known_sigma_1e6_separation=dist / 1e-6,
        late_n24_steps1200=late_occupation(theta, n=24, steps=1200),
        late_n28_steps2400=late_occupation(theta, n=28, steps=2400),
        start_cost_range=[float(min(f.cost for f in fits)), float(max(f.cost for f in fits))],
    )


def starts(row):
    T, sigma = row["T"], row["sigma"]
    ts = np.linspace(0.1 * T, T, SAMPLES)
    truth = trajectory(TRUE, ts, n=10, rtol=2e-13, atol=2e-16)
    target = stack(truth) + np.random.default_rng(row["seed"]).normal(0, sigma, 6 * SAMPLES)
    cache = {}

    def ev(p):
        if "p" not in cache or not np.array_equal(p, cache["p"]):
            z, j = trajectory(p, ts, sensitivity=True)
            cache.update(p=p.copy(), f=(stack(z) - target) / sigma, j=j / sigma)
        return cache

    candidates = []
    for start in ([0.10, -0.02, -0.20], [-0.05, 0.05, 0.5]):
        fit = least_squares(
            lambda p: ev(p)["f"],
            start,
            jac=lambda p: ev(p)["j"],
            bounds=BOUNDS,
            x_scale=[0.05, 0.01, 0.1],
            ftol=1e-9,
            xtol=1e-9,
            gtol=1e-7,
            max_nfev=100,
        )
        candidates.append(
            dict(theta=fit.x.tolist(), chi2=float(2 * fit.cost), success=bool(fit.success))
        )
    return dict(
        T=T,
        sigma=sigma,
        rep=row["rep"],
        original_chi2=row["chi2"],
        original_theta=row["theta"],
        alternatives=candidates,
    )


if __name__ == "__main__":
    rows = [json.loads(l) for l in (ROOT / "trials.jsonl").read_text().splitlines()]
    # Extend the common-noise comparison to all 60 replicates per window.
    selected = [r for r in rows if r["sigma"] == 1e-6 and "late_n24_steps1200" not in r]
    with ProcessPoolExecutor(max_workers=4) as pool:
        additions = list(pool.map(late_row, selected))
        controls = list(pool.map(null_control, (0.03, 0.12, 0.24)))
        check = list(pool.map(starts, [r for r in rows if r["rep"] < 6]))
    changes = {(r["T"], r["sigma"], r["rep"]): r for r in additions}
    rows = [changes.get((r["T"], r["sigma"], r["rep"]), r) for r in rows]
    (ROOT / "trials.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    (ROOT / "diagnostics.json").write_text(
        json.dumps(dict(null_controls=controls, multistart=check), indent=2)
    )
    print(json.dumps(controls, indent=2))
    improved = [
        r for r in check if min(a["chi2"] for a in r["alternatives"]) < r["original_chi2"] - 1e-5
    ]
    print("multistart substantial improvements", len(improved), "of", len(check))
    print(json.dumps(improved, indent=2))
