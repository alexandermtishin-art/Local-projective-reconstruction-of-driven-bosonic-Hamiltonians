"""Build a research figure and a report from saved calculation outputs."""

import hashlib
import json
import platform
from pathlib import Path
import numpy as np
import scipy
from scipy.special import ndtr
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from noise_study import ROOT, TRUE, trajectory

pilot = json.loads((ROOT / "pilot.json").read_text())
summary = json.loads((ROOT / "summary.json").read_text())
diag = json.loads((ROOT / "diagnostics.json").read_text())
trials = [json.loads(x) for x in (ROOT / "trials.jsonl").read_text().splitlines()]
design = pilot["design"]
selected = [r for r in summary if r["sigma"] == 1e-6]
for r in diag["null_controls"]:
    D = r["known_sigma_1e6_separation"]
    r["equal_prior_optimal_binary_error_sigma_1e6"] = float(ndtr(-D / 2))
    r["kl_true_to_fixed_alternative_sigma_1e6"] = D**2 / 2
    r["late_relative_error"] = r["late_n28_steps2400"] / selected[0]["late_exact"] - 1
    ts = np.linspace(0.1 * r["T"], r["T"], 41)
    a = trajectory(np.array(r["theta"]), ts, n=8)
    b = trajectory(np.array(r["theta"]), ts, n=12, rtol=2e-13, atol=2e-16)
    r["null_early_cutoff_check"] = float(np.max(abs(a - b)))
(ROOT / "diagnostics.json").write_text(json.dumps(diag, indent=2))

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.titleweight": "bold",
        "savefig.dpi": 220,
    }
)
fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.5), layout="constrained")
colors = ["#176B87", "#B96D14", "#873E77"]
markers = ["o", "s", "^"]
T = np.array([r["T"] for r in design])
for j, label in enumerate(["U", "W", "Z"]):
    axes[0].loglog(
        T,
        [r["sigma_for_10pct_sd"][j] for r in design],
        marker=markers[j],
        color=colors[j],
        label=label,
        lw=1.8,
    )
    axes[1].loglog(
        [r["T"] for r in selected],
        [100 * r["rmse"][j] / TRUE[j] for r in selected],
        marker=markers[j],
        color=colors[j],
        label=label,
        lw=1.8,
    )
axes[0].set(
    title="a  Local sensitivity estimate",
    xlabel="Window end T",
    ylabel="Noise SD giving 10% parameter SD",
)
axes[1].set(
    title=r"b  Monte Carlo at $\sigma=10^{-6}$",
    xlabel="Window end T",
    ylabel="Relative parameter RMSE (%)",
)
axes[1].axhline(10, color="#777777", ls="--", lw=1)
axes[1].annotate(
    "22 / 60 fits hit a bound",
    xy=(0.03, 740),
    xytext=(0.052, 350),
    fontsize=8,
    arrowprops={"arrowstyle": "->", "color": "#555555"},
)
for ax in axes:
    ax.set_xticks([0.015, 0.03, 0.06, 0.12, 0.24] if ax is axes[0] else [0.03, 0.12, 0.24])
    ax.set_xticklabels(
        ["0.015", "0.03", "0.06", "0.12", "0.24"] if ax is axes[0] else ["0.03", "0.12", "0.24"]
    )
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.grid(True, which="major", alpha=0.2)
    ax.legend(frameon=False, loc="best", ncol=3)
fig.savefig(ROOT / "noise_window.png")
fig.savefig(ROOT / "noise_window.pdf")
plt.close(fig)


def sci(x):
    return f"{x:.3g}"


design_table = "\n".join(
    "| " + str(r["T"]) + " | " + " | ".join(sci(x) for x in r["sigma_for_10pct_sd"]) + " |"
    for r in design
)
mc_table = "\n".join(
    "| "
    + str(r["T"])
    + " | "
    + sci(r["sigma"])
    + " | "
    + " | ".join(f'{100*r["rmse"][j]/TRUE[j]:.3g}' for j in range(3))
    + f' | {r["boundary_count"]}/60 |'
    for r in summary
)
late_table = "\n".join(
    f'| {r["T"]} | {100*r["late_median_relative_error"]:.3g}% | {r["late_count"]} |'
    for r in selected
)
null_table = "\n".join(
    f'| {r["T"]} | {r["theta"][0]:.8f} | {r["theta"][1]:.8f} | {r["raw_rms"]:.3g} | {r["known_sigma_1e6_separation"]:.4g} | {r["late_n28_steps2400"]:.6f} |'
    for r in diag["null_controls"]
)
v = pilot["validation"]
witness = diag["null_controls"][0]
late_diff = max(
    abs(r["late_n24_steps1200"] - r["late_n20_steps600"])
    for r in trials
    if "late_n24_steps1200" in r
)
null_diff = max(
    abs(r["late_n28_steps2400"] - r["late_n24_steps1200"]) for r in diag["null_controls"]
)
report = rf"""# Устойчивость реконструкции бозонного гамильтониана

Расчёт от 25 сентября 2026 года для статьи **Local projective reconstruction of driven bosonic Hamiltonians**, версия файла от 23 сентября 2026 года.

## Основной результат

Точная локальная идентифицируемость совместима с сильной неустойчивостью при конечной точности. В модели статьи слабее всего определяется коэффициент Z. При одинаковом абсолютном шуме 10⁻⁶ увеличение конца окна с 0,03 до 0,12 снижает относительную среднеквадратичную ошибку Z примерно с 740% до 12,2%, а до 0,24 — до 0,453%. В коротком окне большая ошибка зависит от ограничений поиска: 22 из 60 оценок достигают границы. Эти значения означают потерю информативности, а не точную оценку неограниченного риска.

Независимый свидетель потери информации: модель с Z=0, U={witness['theta'][0]:.9f}, W={witness['theta'][1]:.9f} отличается от истинных ранних данных на RMS {witness['raw_rms']:.4g}, но предсказывает позднее число частиц {witness['late_n28_steps2400']:.6f} вместо {selected[0]['late_exact']:.6f}, то есть ошибается на {100*witness['late_relative_error']:.2f}%. При принятом шуме 10⁻⁶ оптимальный бинарный тест между этими двумя заранее известными моделями имеет среднюю ошибку {100*witness['equal_prior_optimal_binary_error_sigma_1e6']:.2f}% при равных априорных вероятностях.

Это результат для заданной модели и схемы данных. Он не устанавливает экспериментальную точность и не доказывает устойчивость восстановления произвольной цепочки Якоби.

## Модель и протокол

Расчёт независимо реализует уравнения (19)–(24) предоставленной рукописи; он не использует исходный программный пакет автора. Единицы безразмерные, ℏ=1:

\[
H(t)=\Omega(t)\left[\hat n+U\binom{{\hat n}}{{2}}+W\binom{{\hat n}}{{4}}+Z\binom{{\hat n}}{{6}}+\frac{{\lambda(t)}}4(a^{{\dagger2}}+a^2)\right],
\]

\[
\Omega(t)=1+0.4t+0.1t^2,\quad\lambda(t)=3+0.2t,\quad(U,W,Z)=(0.05,0.01,0.10).
\]

Начальное состояние — вакуум. Наблюдения — комплексные отношения ζ₂, ζ₄, ζ₆. Для каждого T берутся **41 равномерно расположенный момент в [T/10,T]**. Исходное окно статьи воспроизводится при T=0,03. При изменении T число наблюдений сохраняется, а сетка масштабируется целиком; это не накопительное добавление точек к исходной сетке.

К каждой вещественной и мнимой компоненте независимо добавляется N(0,σ²). Всего один набор содержит 246 вещественных наблюдений. σ — **абсолютное** стандартное отклонение одной компоненты, не относительный шум, не ошибка параметра и не заявленная экспериментальная точность. Шум на отношениях амплитуд моделируется непосредственно; реальные томографические ошибки могут иметь другую ковариацию.

Шумовые данные создаются с 10 чётными состояниями и допусками DOP853 2×10⁻¹³ / 2×10⁻¹⁶. Обратная модель использует 8 чётных состояний и допуски 2×10⁻¹¹ / 2×10⁻¹⁴. Это проверка согласованной параметрической модели с разными численными настройками; она не включает неизвестную модельную ошибку. Чувствительности считаются интегрированием уравнений ∂ψ/∂U, ∂ψ/∂W, ∂ψ/∂Z.

Выполнено 540 нелинейных реконструкций: T=0,03; 0,12; 0,24, σ=10⁻⁸; 10⁻⁶; 10⁻⁴, по 60 независимых реализаций в каждой ячейке. Начальное приближение всегда (0,02;0,02;0,05), не истинные параметры. Минимизируется сумма квадратов компонент, делённых на σ. Границы поиска: −0,5≤U≤0,5, −0,3≤W≤0,3, −1≤Z≤1. Отрицательные значения разрешены для диагностики; стабильность бесконечной лестницы при таких параметрах не предполагается. Попадания на границу учтены отдельно. Регуляризация или априорная положительность не вводились.

Для 54 заранее выбранных наборов, первых шести в каждой ячейке, использованы ещё два старта: (0,10;−0,02;−0,20) и (−0,05;0,05;0,50). Ни один не снизил χ² более чем на 10⁻⁵ относительно основного решения. Это проверка чувствительности к старту, а не доказательство глобальной оптимальности.

## Почему глубина требует точности

Пусть f(θ) — вектор всех вещественных и мнимых наблюдений, J=∂f/∂θ. В локальном линейном приближении при независимом гауссовом шуме:

\[
\mathrm{{Cov}}(\hat\theta)\simeq\sigma^2(J^T J)^{{-1}}.
\]

Эта оценка применима около истинного решения, при отсутствии активных границ и достаточно слабом шуме. Она не гарантирует точность ограниченного нелинейного оценивателя при большом шуме. При иной ковариации шумов нужно использовать JᵀΣ⁻¹J.

На коротких временах уникальный путь по лестнице даёт

\[
\zeta_{{2m}}(t)=a_m t^m+b_m t^{{m+1}}+O(t^{{m+2}}),\quad
a_m=\frac{{(-i)^m}}{{m!}}\prod_{{j=0}}^{{m-1}}g_j(0).
\]

Для независимой поправки к энергии впервые достигнутого уровня производная следующего коэффициента равна −iaₘ/(m+1). В параметризации статьи при G(0)=3/4:

\[
\partial_U\zeta_2=-0.530330\,t^2+O(t^3),\quad
\partial_W\zeta_4=i\,0.459279\,t^3+O(t^4),\quad
\partial_Z\zeta_6=0.471671\,t^4+O(t^5).
\]

Поэтому для фиксированного числа точек на масштабируемой сетке ведущие маловременные масштабы стандартных ошибок пропорциональны σ/T², σ/T³ и σ/T⁴ соответственно. В численных оценках ниже использован полный совместный якобиан, включая корреляции трёх параметров; степенные оценки служат объяснением предела T→0, а не заменяют расчёт на конечном окне.

Допустимый σ, при котором локальная стандартная ошибка составляет 10% истинного значения:

| Конец окна T | U | W | Z |
|---|---:|---:|---:|
{design_table}

«10% стандартной ошибки» не означает, что 95% реализаций попадут в коридор ±10%. Для нормального линейного приближения такое требование к 95%-му интервалу уменьшило бы допустимый σ ещё примерно в 1,96 раза.

## Шумовые реконструкции

В таблице приведён 100×RMSE/|истинный параметр|. Все 60 оценок в каждой ячейке включены, в том числе достигающие границ.

| T | σ | Ошибка U % | Ошибка W % | Ошибка Z % | Граница поиска |
|---|---:|---:|---:|---:|---:|
{mc_table}

Все 540 запусков удовлетворили критерию остановки оптимизатора. Это не свидетельство точности: при слабой информативности оптимизатор успешно завершает и заведомо ненадёжные реконструкции. Например, в исходном окне при σ=10⁻⁶ параметр U ещё имеет ошибку около 1,26%, тогда как W и Z уже не определяются надёжно.

В файлах результатов сохранены эмпирические квантили, RMSE, доли попаданий в ±10%, число границ и приближённые Wald-оценки. Квантили описывают распределение 60 реконструкций, а не доверительный интервал из одного эксперимента. Wald-оценки и их покрытие в режимах с активными границами не интерпретируются как достоверная статистическая калибровка. Формальная частота ложного обнаружения Z отдельно не исследована.

## Альтернатива без шестого порядка

Для каждого окна к бесшумным данным подбирались U и W при Z=0. Проверены четыре начальных приближения. Таблица описывает найденные альтернативы; для вывода о неразличимости достаточно существования одной такой альтернативы, поэтому доказательство глобального минимума не требуется.

| T | U при Z=0 | W при Z=0 | RMS разности данных | D при σ=10⁻⁶ | Прогноз ⟨n⟩(1,2) |
|---|---:|---:|---:|---:|---:|
{null_table}

Здесь D=‖f(θист)−f(θальт)‖₂/σ учитывает весь набор из 246 компонент. Для двух фиксированных средних с общей гауссовой ковариацией σ²I оптимальная средняя ошибка бинарного различения при равных априорных вероятностях равна

\[
P_{{\rm err}}^*=\Phi(-D/2).
\]

Для T=0,03 имеем D={witness['known_sigma_1e6_separation']:.6f}, KL=D²/2={witness['kl_true_to_fixed_alternative_sigma_1e6']:.6f}, Pош={100*witness['equal_prior_optimal_binary_error_sigma_1e6']:.2f}%. То есть даже в облегчённой задаче, где известны обе кандидатные модели и σ, различение почти случайно. Это ограничение информации в выбранном наборе наблюдений; изменение оптимизатора или регуляризации само по себе его не устраняет. Дополнительные априорные сведения могут изменить задачу.

При T=0,12 та же процедура даёт D≈8,40. Это показывает существенное усиление различимости данной пары при расширении временного окна. Не следует отождествлять различение Z=0 и Z=0,1 с оценкой Z с относительной ошибкой 10%: это разные требования.

## Поздний прогноз

После восстановления параметры фиксируются и модель распространяется до t=1,2. Законы Ω(t), λ(t) предполагаются известными на всём этом интервале; они не выводятся из локальных данных. При σ=10⁻⁶ прогноз посчитан для всех 60 реализаций каждого окна. В остальных ячейках — для первых десяти, выбранных до просмотра результатов.

| T при σ=10⁻⁶ | Медианная абсолютная относительная ошибка ⟨n⟩(1,2) | Число прогнозов |
|---|---:|---:|
{late_table}

Это характеристика прогноза внутри заданного класса гамильтонианов. Она не переносится на неизвестный будущий привод и не учитывает декогеренцию.

## Численная проверка

- Независимо воспроизведено ⟨n⟩(1,2)={v['late_n24_steps1200']:.12f}, согласующееся с 3,5296 в таблице статьи.
- Максимальная разность ранних координат при 8 и 12 состояниях на самом длинном окне: {v['early_n8_vs_n12_max']:.3g}; при 12 и 16: {v['early_n12_vs_n16_max']:.3g} для истинной модели.
- Относительная разность аналитических чувствительностей и центральных конечных разностей по столбцам U,W,Z: {', '.join(sci(x) for x in v['sensitivity_fd_relative_column_error'])}.
- Поздняя динамика интегрируется унитарной схемой Магнуса четвёртого порядка без коммутаторов. Сравниваются 20 состояний / 600 шагов и 24 состояния / 1200 шагов. Максимальная разность среди всех рассчитанных шумовых прогнозов: {late_diff:.3g}.
- Для альтернатив Z=0 дополнительно сравниваются 24 состояния / 1200 шагов и 28 состояний / 2400 шагов; максимальная разность {null_diff:.3g}.

Эти проверки относятся к рассчитанным траекториям; они не являются общей оценкой погрешности для всех возможных параметров.

## Что можно добавить в статью

Содержательное дополнение — подраздел о finite-precision reconstruction depth с формулой локальной ковариации, одним рисунком и конкретной парой неразличимых коротких траекторий. Главный вывод: структурная идентифицируемость не гарантирует устойчивую реконструкцию; разрешаемая глубина зависит от точности и длительности наблюдения. Предложенный английский текст ниже относится только к выполненному параметрическому исследованию.

**Finite-precision reconstruction depth.** We assessed finite-window parameter recovery in the bosonic model of Eqs. (19)–(24), keeping the drive laws fixed and known. Independent Gaussian noise with standard deviation σ was added to each real and imaginary component of ζ₂, ζ₄ and ζ₆ at 41 times in [0.1T,T]. Sixty noise realizations were fitted for each window and noise level. At σ=10⁻⁶, the relative root-mean-square error of Z was 12.2% for T=0.12 and 0.453% for T=0.24; at T=0.03, the reconstruction was poorly constrained, with 22 of 60 fits reaching a parameter bound. The local covariance estimate σ²(JᵀJ)⁻¹ explains the depth dependence: the leading sensitivities to U, W and Z scale as t², t³ and t⁴, respectively. An explicit Z=0 alternative fitted to the original window differs from the true early data by only 5.24×10⁻⁹ RMS, yet overpredicts the final occupation by 49.6%. Under the specified σ=10⁻⁶ noise model, even optimal discrimination between these two fixed alternatives has an equal-prior error probability of 48.4%. Thus exact identifiability coexists with an acquisition-dependent limit on practically recoverable depth. These tests assume the stated parameterized Hamiltonian and observation-noise model; they do not establish noise stability for arbitrary time-dependent Jacobi chains or an experimental tomography protocol.

До включения в новую научную версию следует сохранить все оговорки о фиксированном классе моделей и модели шума. Текущая техническая редакционная правка требует только согласования имени; предоставленный DOCX этим расчётом не изменён.

## Воспроизведение

В архиве находятся исходный код, все 540 реализаций, сводки, диагностика, рисунок и этот отчёт. Команды запуска из каталога архива:

```bash
OPENBLAS_NUM_THREADS=1 python noise_study.py --mode pilot
OPENBLAS_NUM_THREADS=1 python noise_study.py --mode mc --reps 60 --workers 4
OPENBLAS_NUM_THREADS=1 python diagnostics.py
OPENBLAS_NUM_THREADS=1 python noise_study.py --mode summary
OPENBLAS_NUM_THREADS=1 python make_report.py
```

Фиксированные seeds записаны в каждой строке trials.jsonl. Расчёт выполнен с Python {platform.python_version()}, NumPy {np.__version__}, SciPy {scipy.__version__}, Matplotlib {matplotlib.__version__}. Начальные данные и модели полностью заданы в коде; внешние экспериментальные данные отсутствуют.
"""
(ROOT / "CommPhys_noise_report.md").write_text(report)
(ROOT / "requirements.txt").write_text(
    f"numpy=={np.__version__}\nscipy=={scipy.__version__}\nmatplotlib=={matplotlib.__version__}\n"
)
print("report and figure saved")
print(
    "late medians", [(r["T"], r["late_count"], r["late_median_relative_error"]) for r in selected]
)
print("witness", json.dumps(witness, indent=2))
