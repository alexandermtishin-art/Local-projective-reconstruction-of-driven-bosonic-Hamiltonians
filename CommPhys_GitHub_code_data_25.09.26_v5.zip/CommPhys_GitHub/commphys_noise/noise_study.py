"""Independent finite-window noise study of manuscript Eqs. (19)-(24).

Run with Python 3, numpy and scipy. No experimental data are used.
Noise sigma denotes the standard deviation of EACH real/imaginary component
of the complex projective coordinates, independently over levels and times.
"""

import argparse
import json
import math
import os
import time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from scipy.linalg import eigh

ROOT = Path(__file__).resolve().parent
TRUE = np.array([0.05, 0.01, 0.10])
SAMPLES = 41
BOUNDS = (np.array([-0.5, -0.3, -1.0]), np.array([0.5, 0.3, 1.0]))


def matrices(n):
    occ = 2 * np.arange(n)
    basis = np.array(
        [[math.comb(int(k), p) if k >= p else 0 for p in (2, 4, 6)] for k in occ], float
    )
    off = np.sqrt((occ[:-1] + 1) * (occ[:-1] + 2))
    return occ, basis, off


def stack(z):
    return np.concatenate((z.real.ravel(), z.imag.ravel()))


def trajectory(theta, times, n=8, sensitivity=False, rtol=2e-11, atol=2e-14):
    occ, basis, off = matrices(n)
    diag = occ + basis @ theta
    y0 = np.zeros((n, 4 if sensitivity else 1), complex)
    y0[0, 0] = 1

    def rhs(t, flat):
        y = flat.reshape(y0.shape)
        omega = 1 + 0.4 * t + 0.1 * t * t
        g = omega * (3 + 0.2 * t) / 4
        h = omega * diag[:, None] * y
        h[1:] += g * off[:, None] * y[:-1]
        h[:-1] += g * off[:, None] * y[1:]
        if sensitivity:
            h[:, 1:] += omega * basis * y[:, :1]
        return (-1j * h).ravel()

    sol = solve_ivp(
        rhs, (0, float(times[-1])), y0.ravel(), t_eval=times, method="DOP853", rtol=rtol, atol=atol
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    y = sol.y.reshape(n, y0.shape[1], -1)
    c = y[:, 0]
    z = c[1:4] / c[0]
    if not sensitivity:
        return z
    dz = (y[1:4, 1:] * c[0][None, None, :] - c[1:4, None, :] * y[0, 1:][None, :, :]) / c[0][
        None, None, :
    ] ** 2
    jac = np.column_stack([stack(dz[:, j]) for j in range(3)])
    return z, jac


def late_occupation(theta, n=20, steps=600, end=1.2):
    """Fourth-order commutator-free Magnus propagation, Hermitian exponentials.

    Two Gauss nodes; product exp(-i h (a H1+b H2)) exp(-i h (b H1+a H2)).
    Right exponential acts first; a=(3-2sqrt(3))/12, b=(3+2sqrt(3))/12.
    """
    occ, basis, off = matrices(n)
    diagonal = np.diag(occ + basis @ theta)
    pump = np.diag(off, 1) + np.diag(off, -1)
    a, b = (3 - 2 * np.sqrt(3)) / 12, (3 + 2 * np.sqrt(3)) / 12
    nodes = 0.5 + np.array([-1, 1]) * np.sqrt(3) / 6
    state = np.zeros(n, complex)
    state[0] = 1
    dt = end / steps
    for k in range(steps):
        ts = (k + nodes) * dt
        hs = [(1 + 0.4 * t + 0.1 * t * t) * (diagonal + (3 + 0.2 * t) / 4 * pump) for t in ts]
        for mat in (b * hs[0] + a * hs[1], a * hs[0] + b * hs[1]):
            vals, vecs = eigh(mat, check_finite=False)
            state = vecs @ (np.exp(-1j * dt * vals) * (vecs.T @ state))
    return float(occ @ abs(state) ** 2)


def design():
    rows = []
    for T in (0.015, 0.03, 0.06, 0.12, 0.24):
        ts = np.linspace(0.1 * T, T, SAMPLES)
        z, jac = trajectory(TRUE, ts, sensitivity=True)
        _, s, vt = np.linalg.svd(jac, full_matrices=False)
        pinv = np.linalg.pinv(jac)
        amplification = np.sqrt(np.sum(pinv**2, axis=1))
        row = dict(
            T=T,
            singular_values=s.tolist(),
            condition=float(s[0] / s[-1]),
            sd_per_unit_sigma=amplification.tolist(),
            sigma_for_10pct_sd=(0.1 * TRUE / amplification).tolist(),
            max_abs_coordinate=np.max(abs(z), axis=1).tolist(),
            max_abs_dz_dZ=float(
                np.max(np.sqrt(jac[: 3 * SAMPLES, 2] ** 2 + jac[3 * SAMPLES :, 2] ** 2))
            ),
            weakest_direction=vt[-1].tolist(),
        )
        rows.append(row)
    return rows


def validate():
    ts = np.linspace(0.024, 0.24, SAMPLES)
    z, jac = trajectory(TRUE, ts, sensitivity=True)
    z12 = trajectory(TRUE, ts, n=12, rtol=2e-13, atol=2e-16)
    z16 = trajectory(TRUE, ts, n=16, rtol=2e-13, atol=2e-16)
    fd = []
    for i in range(3):
        d = np.zeros(3)
        d[i] = 1e-5
        fd.append(
            stack(
                (
                    trajectory(TRUE + d, ts, rtol=2e-13, atol=2e-16)
                    - trajectory(TRUE - d, ts, rtol=2e-13, atol=2e-16)
                )
                / (2 * d[i])
            )
        )
    fd = np.column_stack(fd)
    nominal = late_occupation(TRUE)
    return dict(
        early_n8_vs_n12_max=float(np.max(abs(z - z12))),
        early_n12_vs_n16_max=float(np.max(abs(z12 - z16))),
        sensitivity_fd_relative_column_error=(
            np.linalg.norm(jac - fd, axis=0) / np.linalg.norm(jac, axis=0)
        ).tolist(),
        late_n20_steps600=nominal,
        late_n20_steps1200=late_occupation(TRUE, steps=1200),
        late_n24_steps1200=late_occupation(TRUE, n=24, steps=1200),
        late_article_rounded=3.5296,
    )


def one_trial(task):
    T, sigma, rep, seed = task
    ts = np.linspace(0.1 * T, T, SAMPLES)
    rng = np.random.default_rng(seed)
    # Higher cutoff and tighter tolerances for synthetic truth than inverse model.
    truth = trajectory(TRUE, ts, n=10, rtol=2e-13, atol=2e-16)
    target = stack(truth) + rng.normal(0, sigma, 6 * SAMPLES)
    cache = {}

    def evaluate(theta):
        if "theta" not in cache or not np.array_equal(theta, cache["theta"]):
            z, j = trajectory(theta, ts, sensitivity=True)
            cache.update(theta=theta.copy(), f=(stack(z) - target) / sigma, j=j / sigma)
        return cache

    fit = least_squares(
        lambda p: evaluate(p)["f"],
        [0.02, 0.02, 0.05],
        jac=lambda p: evaluate(p)["j"],
        bounds=BOUNDS,
        x_scale=[0.05, 0.01, 0.1],
        ftol=1e-9,
        xtol=1e-9,
        gtol=1e-7,
        max_nfev=60,
    )
    j = evaluate(fit.x)["j"]
    cov = np.linalg.pinv(j) @ np.linalg.pinv(j).T
    sd = np.sqrt(np.diag(cov))
    boundary = np.any(np.minimum(fit.x - BOUNDS[0], BOUNDS[1] - fit.x) < 1e-5)
    result = dict(
        T=T,
        sigma=sigma,
        rep=rep,
        seed=int(seed),
        theta=fit.x.tolist(),
        se=sd.tolist(),
        success=bool(fit.success),
        nfev=int(fit.nfev),
        boundary=bool(boundary),
        chi2=float(2 * fit.cost),
        z_wald_detect=bool(abs(fit.x[2]) > 1.96 * sd[2]),
    )
    # Fixed subset chosen BEFORE fitting, no selection on successful outcomes.
    if rep < 10:
        result["late_n20_steps600"] = late_occupation(fit.x)
        result["late_n24_steps1200"] = late_occupation(fit.x, n=24, steps=1200)
    return result


def summarize(rows):
    summaries = []
    exact = late_occupation(TRUE, n=24, steps=1200)
    for T in sorted(set(r["T"] for r in rows)):
        for sigma in sorted(set(r["sigma"] for r in rows)):
            group = [r for r in rows if r["T"] == T and r["sigma"] == sigma]
            if not group:
                continue
            p = np.array([r["theta"] for r in group])
            se = np.array([r["se"] for r in group])
            late = [r for r in group if "late_n24_steps1200" in r]
            latevals = np.array([r["late_n24_steps1200"] for r in late])
            conv = np.array([abs(r["late_n20_steps600"] - r["late_n24_steps1200"]) for r in late])
            summaries.append(
                dict(
                    T=T,
                    sigma=sigma,
                    count=len(group),
                    median=np.median(p, axis=0).tolist(),
                    q025=np.quantile(p, 0.025, axis=0).tolist(),
                    q975=np.quantile(p, 0.975, axis=0).tolist(),
                    rmse=np.sqrt(np.mean((p - TRUE) ** 2, axis=0)).tolist(),
                    within_10pct=np.mean(abs(p - TRUE) <= 0.1 * TRUE, axis=0).tolist(),
                    wald_coverage=np.mean(abs(p - TRUE) <= 1.96 * se, axis=0).tolist(),
                    z_wald_detection_fraction=np.mean([r["z_wald_detect"] for r in group]),
                    boundary_count=sum(r["boundary"] for r in group),
                    failure_count=sum(not r["success"] for r in group),
                    late_count=len(late),
                    late_exact=exact,
                    late_median_relative_error=float(np.median(abs(latevals / exact - 1))),
                    late_max_convergence_difference=float(np.max(conv)),
                )
            )
    return summaries


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["pilot", "mc", "summary"], default="pilot")
    ap.add_argument("--reps", type=int, default=60)
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()
    start = time.time()
    if args.mode == "pilot":
        out = dict(
            model="Manuscript Eqs.19-24 independently implemented",
            truth=TRUE.tolist(),
            samples=SAMPLES,
            noise="independent normal(0,sigma) on each real/imaginary coordinate sample",
            validation=validate(),
            design=design(),
        )
        (ROOT / "pilot.json").write_text(json.dumps(out, indent=2))
        print(json.dumps(out, indent=2), flush=True)
    elif args.mode == "mc":
        tasks = []
        for it, T in enumerate((0.03, 0.12, 0.24)):
            for js, sigma in enumerate((1e-8, 1e-6, 1e-4)):
                for rep in range(args.reps):
                    tasks.append((T, sigma, rep, 20260925 + 100000 * it + 1000 * js + rep))
        with (ROOT / "trials.jsonl").open("w") as f, ProcessPoolExecutor(
            max_workers=args.workers
        ) as pool:
            for k, row in enumerate(pool.map(one_trial, tasks, chunksize=1)):
                f.write(json.dumps(row) + "\n")
                f.flush()
                if (k + 1) % 20 == 0:
                    print(f"{k+1}/{len(tasks)} elapsed={time.time()-start:.1f}s", flush=True)
    else:
        rows = [json.loads(l) for l in (ROOT / "trials.jsonl").read_text().splitlines()]
        out = summarize(rows)
        (ROOT / "summary.json").write_text(json.dumps(out, indent=2))
        print(json.dumps(out, indent=2), flush=True)
    print("elapsed", time.time() - start, flush=True)


if __name__ == "__main__":
    main()
