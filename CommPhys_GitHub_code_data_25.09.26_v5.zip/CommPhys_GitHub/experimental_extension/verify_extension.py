"""Verify probability signs, seeded paths, saved estimates and preparation-aware controls."""

from pathlib import Path
import json, sys, subprocess
import numpy as np

R = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
import measurement_preparation as m

rng = np.random.default_rng(410)
maxerr = 0.0
for _ in range(100):
    c = rng.normal(size=6) + 1j * rng.normal(size=6)
    c /= np.linalg.norm(c)
    for n in range(1, 4):
        u = c[n] * c[0].conj()
        b = (abs(c[0]) ** 2 + abs(c[n]) ** 2) / 2
        for phase, v in [(1, u.real), (1j, u.imag)]:
            for sign in [-1, 1]:
                ket = np.zeros(6, complex)
                ket[0] = 1 / np.sqrt(2)
                ket[n] = sign * phase / np.sqrt(2)
                maxerr = max(maxerr, abs(abs(np.vdot(ket, c)) ** 2 - (b + sign * v)))
assert maxerr < 1e-14
for n in range(2, 6):
    c = np.zeros(6, complex)
    c[0] = np.sqrt(1 - 1e-6)
    c[1] = 0.001j
    deriv = np.linalg.matrix_power(-1j * m.H(0), n - 1) @ c
    expected = 0.001j * (-1j) ** (n - 1) * np.prod(m.G[1:n])
    assert abs(deriv[n] - expected) < 1e-15
j = json.loads((R / "measurement_preparation_results.json").read_text())
z = np.load(R / "measurement_trials.npz")
assert sum(z[k].shape[0] for k in z.files) == 2700
for r in j["measurement_rows"]:
    ti = [0.12, 0.24, 0.48].index(r["T"])
    a = z[f"shot_T{ti}_S{r['shots_per_setting']}"]
    assert np.allclose(
        np.sqrt(np.mean((a - m.TRUTH) ** 2, axis=0)), r["rmse"], rtol=1e-12, atol=1e-12
    )
assert len(j["preparation_rows"]) == 72
p = json.loads((R / "prep_aware_results.json").read_text())
assert len(p["preparation_rows"]) == 72
for r in p["preparation_rows"]:
    assert abs(r["free_additional_error"][1][2]) < 5 * r["epsilon"]
out = subprocess.run(
    [sys.executable, str(R / "check_seed_jet.py")], capture_output=True, text=True, check=True
).stdout
assert all(float(l.split()[-1]) < 1e-14 for l in out.strip().splitlines())
print(
    "PASS: 1200 projector probabilities, seeded paths at depths 2–5, 2700 shot reconstructions, 72 preparation controls,"
)
print(
    "      seeded-jet identities (exact Taylor jets) and 72 preparation-aware controls (additional error < 5 eps)."
)
