"""Regenerate every computed result and figure of the paper with one command.

    python run_all.py                 # everything except the expensive bosonic noise Monte Carlo
    python run_all.py --with-noise    # also rerun the 540 bosonic noise fits (hours)
    python run_all.py --workers 8     # worker processes for the noise study

Outputs are overwritten in place. Run on a copy of the archive if you want to keep the
pristine files for checksum verification (python verify_package.py).
"""
import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(script, *args):
    t0 = time.time()
    print(f"[run] {script} {' '.join(args)}", flush=True)
    subprocess.run([sys.executable, str(ROOT / script), *args], check=True, cwd=ROOT)
    print(f"[done] {script} ({time.time() - t0:.0f} s)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--with-noise", action="store_true")
    ap.add_argument("--workers", default="4")
    a = ap.parse_args()
    # original release: hierarchy, cutoff audit, arbitrary Jacobi control
    run("original/projective_reconstruction_hierarchy_v3_3.py")
    run("original/branchwise_cutoff_convergence_v3_3.py")
    run("original/arbitrary_jacobi_control_v3_3.py")
    # bosonic noise study (Fig. 2, Table 2)
    if a.with_noise:
        run("commphys_noise/noise_study.py", "--mode", "pilot")
        run("commphys_noise/noise_study.py", "--mode", "mc", "--reps", "60", "--workers", a.workers)
        run("commphys_noise/diagnostics.py")
        run("commphys_noise/noise_study.py", "--mode", "summary")
        run("commphys_noise/make_report.py")
    # Jacobi controls, exact checks, finite-window estimates (Fig. 3), efficient information
    run("strengthened/jacobi_strengthening.py")
    run("strengthened/schur_check.py")
    # measurement, preparation and preparation-aware controls (Fig. 4)
    run("experimental_extension/measurement_preparation.py")
    run("experimental_extension/check_seed_jet.py")
    run("experimental_extension/prep_aware_controls.py")
    # figures
    run("strengthened/figures.py")
    run("experimental_extension/figures_measurement.py")
    # consistency of regenerated data with stored summaries
    run("original/verify_release.py")
    run("experimental_extension/verify_extension.py")
    print("All calculations regenerated.")


if __name__ == "__main__":
    main()
