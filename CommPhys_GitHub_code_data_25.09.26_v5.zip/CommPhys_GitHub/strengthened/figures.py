import json, csv
from pathlib import Path
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "original"
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)
colors = ["#0B6FA0", "#BB6A12", "#853D78"]


def save(fig, name):
    fig.savefig(ROOT / (name + ".png"), dpi=350, bbox_inches="tight")
    fig.savefig(ROOT / (name + ".pdf"), bbox_inches="tight")
    plt.close(fig)


with (BASE / "data/Figure_1_data.csv").open() as f:
    rows = list(csv.DictReader(f))
data = {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}
fig, ax = plt.subplots(figsize=(6.8, 3.7), layout="constrained")
ax.plot(data["time"], data["exact_U_W_Z"], color="#202020", lw=2.4, label="Exact")
for key, col, ls, mk, label in zip(
    ["fit_U_only", "fit_U_W", "fit_U_W_Z"],
    colors,
    ["--", "-.", ":"],
    ["o", "s", "^"],
    ["U fit", "U + W fit", "U + W + Z fit"],
):
    ax.plot(
        data["time"],
        data[key],
        color=col,
        ls=ls,
        marker=mk,
        markevery=45,
        ms=3.5,
        lw=1.7,
        label=label,
    )
ax.axvspan(0, 0.03, color="#999999", alpha=0.18, lw=0, label="Fitting window")
ax.set(
    xlabel=r"Time $t$ (units of $\Omega(0)^{-1}$)", ylabel=r"$\langle\hat n\rangle$", xlim=(0, 1.2)
)
ax.legend(frameon=False, fontsize=9)
save(fig, "Figure_1")
pilot = json.loads((ROOT.parent / "commphys_noise/pilot.json").read_text())["design"]
summary = json.loads((ROOT.parent / "commphys_noise/summary.json").read_text())
selected = [r for r in summary if r["sigma"] == 1e-6]
trials = [
    json.loads(l) for l in (ROOT.parent / "commphys_noise/trials.jsonl").read_text().splitlines()
]
fig, axs = plt.subplots(1, 2, figsize=(6.8, 3.35), layout="constrained")
for j, name in enumerate(["U", "W", "Z"]):
    axs[0].loglog(
        [r["T"] for r in pilot],
        [r["sigma_for_10pct_sd"][j] for r in pilot],
        marker=["o", "s", "^"][j],
        color=colors[j],
        label=name,
        ms=4,
    )
    Ts = [0.03, 0.12, 0.24]
    med = []
    lo = []
    hi = []
    for T in Ts:
        e = np.array(
            [
                100 * abs(t["theta"][j] - [0.05, 0.01, 0.1][j]) / [0.05, 0.01, 0.1][j]
                for t in trials
                if t["T"] == T and t["sigma"] == 1e-6
            ]
        )
        q = np.quantile(e, [0.25, 0.5, 0.75])
        med.append(q[1])
        lo.append(q[1] - q[0])
        hi.append(q[2] - q[1])
    axs[1].errorbar(
        Ts,
        med,
        yerr=[lo, hi],
        marker=["o", "s", "^"][j],
        color=colors[j],
        label=name,
        ms=4,
        capsize=2,
        lw=1.4,
    )
    axs[1].set_xscale("log")
    axs[1].set_yscale("log")
axs[0].set(xlabel="Window end T", ylabel="Noise SD for 10% parameter SD")
axs[1].set(xlabel="Window end T", ylabel="Median relative parameter error (%)")
axs[1].axhline(10, color="#777777", ls="--", lw=0.8)
for i, ax in enumerate(axs):
    ax.set_title("ab"[i], loc="left", fontweight="bold", fontsize=11)
    ax.set_xticks([0.03, 0.12, 0.24])
    ax.set_xticklabels(["0.03", "0.12", "0.24"])
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.grid(alpha=0.18)
    ax.legend(
        frameon=False,
        fontsize=8,
        loc="lower right" if i == 0 else "lower left",
        ncol=3,
        handlelength=1,
        columnspacing=0.6,
    )
save(fig, "Figure_2")
r = json.loads((ROOT / "jacobi_strengthening_results.json").read_text())["finite_window"]
raw = np.load(ROOT / "jacobi_window_trials.npz")
truth = np.asarray(r["truth"])
Ts = [0.015, 0.03, 0.06, 0.12, 0.24, 0.48, 0.96]
fig, ax = plt.subplots(figsize=(6.8, 3.7), layout="constrained")
for sigma, col, mk, lab in zip(
    ["1e-10", "1e-08", "1e-06"],
    colors,
    ["o", "s", "^"],
    [r"$\sigma=10^{-10}$", r"$\sigma=10^{-8}$", r"$\sigma=10^{-6}$"],
):
    q = np.array(
        [
            np.quantile(abs(raw[f"T{i}_p2_s{sigma}"][:, 1, 2] - truth[1, 2]), [0.25, 0.5, 0.75])
            for i in range(7)
        ]
    )
    ax.fill_between(Ts, q[:, 0], q[:, 2], color=col, alpha=0.15, lw=0)
    ax.loglog(Ts, q[:, 1], color=col, marker=mk, ms=4.5, lw=1.6, label=lab)
rows = [x for x in r["rows"] if x["sigma"] == 1e-8 and x["extra_orders"] == 2]
ax.loglog(
    Ts,
    [abs(x["bias"][1][2]) for x in rows],
    color="#333333",
    ls="--",
    lw=1.4,
    label="Noiseless bias",
)
ax.axhline(0.07, color="#777777", ls=":", lw=1, label="10% of true offset")
ax.set(xlabel="Window end T", ylabel=r"Absolute error in $E_3-E_0$ ($\hbar=1$)")
ax.set_xticks(Ts)
ax.set_xticklabels([str(t) for t in Ts])
ax.xaxis.set_minor_formatter(NullFormatter())
ax.grid(alpha=0.18)
ax.legend(frameon=False, fontsize=9, loc="upper right")
save(fig, "Figure_3")
