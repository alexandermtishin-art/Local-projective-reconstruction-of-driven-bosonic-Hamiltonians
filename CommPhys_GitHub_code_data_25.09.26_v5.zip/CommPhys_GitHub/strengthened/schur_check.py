"""Efficient Fisher information for the level-3 diagonal shift with unknown nuisance parameters.

Six-level control of jacobi_strengthening.py; observations z_1..z_3 (real and imaginary parts)
at 61 points in [T/10, T]; additive noise sigma per component. The ratio of the efficient
information (Schur complement) to the fixed-nuisance information is independent of sigma.
"""

import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from jacobi_strengthening import E, ED, EDD, G, GD, GDD

ROOT = Path(__file__).resolve().parent
theta0 = np.concatenate([E, ED, EDD, G, GD, GDD])  # 18 + 15 = 33 parameters
names = (
    [f"E{j}" for j in range(6)]
    + [f"Ed{j}" for j in range(6)]
    + [f"Edd{j}" for j in range(6)]
    + [f"g{j}" for j in range(5)]
    + [f"gd{j}" for j in range(5)]
    + [f"gdd{j}" for j in range(5)]
)


def coords(theta, T):
    e, ed, edd = theta[:6], theta[6:12], theta[12:18]
    g, gd, gdd = theta[18:23], theta[23:28], theta[28:33]

    def H(t):
        gg = g + gd * t + 0.5 * gdd * t * t
        return np.diag(e + ed * t + 0.5 * edd * t * t) + np.diag(gg, 1) + np.diag(gg, -1)

    ts = np.linspace(0.1 * T, T, 61)
    y = np.zeros(6, complex)
    y[0] = 1
    s = solve_ivp(
        lambda t, c: -1j * H(t) @ c, (0, T), y, t_eval=ts, method="DOP853", rtol=1e-13, atol=1e-18
    )
    z = s.y[1:4] / s.y[0]
    return np.concatenate([z.real.ravel(), z.imag.ravel()])


def jac(T, h=1e-6):
    cols = []
    for k in range(33):
        tp = theta0.copy()
        tm = theta0.copy()
        tp[k] += h
        tm[k] -= h
        cols.append((coords(tp, T) - coords(tm, T)) / (2 * h))
    return np.array(cols).T


rows = []
target = names.index("E3")
# E0(t) is the invisible scalar gauge and is excluded from every nuisance set.
SETS = {
    "layer_parameters": ["E1", "E2", "g0", "g1", "g2", "gd0", "gd1", "gd2"],
    "layer_and_deeper_levels": [
        "E1",
        "E2",
        "E4",
        "E5",
        "g0",
        "g1",
        "g2",
        "g3",
        "g4",
        "gd0",
        "gd1",
        "gd2",
    ],
    "all_time_law_parameters": [n for n in names if n not in ("E3", "E0", "Ed0", "Edd0")],
}
for T in [0.12, 0.24, 0.48]:
    J = jac(T)
    v = J[:, target]
    out = dict(T=T, fixed_information_per_unit_sigma2=float(v @ v))
    for label, nuis in SETS.items():
        A = J[:, [names.index(n) for n in nuis]]
        A = A / np.linalg.norm(A, axis=0)
        U, S, _ = np.linalg.svd(A, full_matrices=False)
        Q = U[:, S > 1e-10 * S[0]]
        r = v - Q @ (Q.T @ v)  # efficient information = |(I-P)v|^2 (Schur complement)
        out[label] = dict(
            ratio=float((r @ r) / (v @ v)),
            sd_inflation=float(np.sqrt((v @ v) / (r @ r))),
            n_nuisance=len(nuis),
        )
    rows.append(out)
    print(T, {k: round(v["sd_inflation"], 2) for k, v in out.items() if isinstance(v, dict)})
(ROOT / "schur_results.json").write_text(json.dumps(dict(description=__doc__, rows=rows), indent=2))
