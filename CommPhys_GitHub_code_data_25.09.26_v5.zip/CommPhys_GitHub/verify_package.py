from pathlib import Path
import hashlib, json
import numpy as np

root = Path(__file__).resolve().parent
m = json.loads((root / "SHA256_manifest.json").read_text())
for name, h in m.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == h, name
j = json.loads((root / "strengthened/jacobi_strengthening_results.json").read_text())
z = np.load(root / "strengthened/jacobi_window_trials.npz")
assert sum(z[k].shape[0] for k in z.files) == 8400
for r in j["finite_window"]["rows"]:
    ti = [0.015, 0.03, 0.06, 0.12, 0.24, 0.48, 0.96].index(r["T"])
    a = z[f"T{ti}_p{r['extra_orders']}_s{r['sigma']}"]
    rmse = np.sqrt(np.mean((a - np.asarray(j["finite_window"]["truth"])) ** 2, axis=0))
    assert np.allclose(rmse, r["rmse"], rtol=1e-12, atol=1e-12)
assert len((root / "commphys_noise/trials.jsonl").read_text().splitlines()) == 540
print(f"Verified {len(m)} files, 8400 Jacobi estimates and 540 bosonic trial records.")
