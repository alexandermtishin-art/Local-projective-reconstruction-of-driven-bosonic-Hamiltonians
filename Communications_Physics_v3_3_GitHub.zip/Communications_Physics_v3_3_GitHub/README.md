# Local projective reconstruction of driven bosonic Hamiltonians — v3.3 reproducibility files

A. M. Tishin

This repository contains the code and numerical data used to reproduce the hierarchical reconstruction, forward-prediction comparison, branchwise cutoff audit, independent Jacobi-chain control, and Figure 1 associated with manuscript release v3.3.

The manuscript itself is intentionally **not** included in this repository archive.

## Contents

- `projective_reconstruction_hierarchy_v3_3.py` — nested short-window projective fits, forward occupation curves, Figure 1, `Figure_1_data.csv`, and `Fit_summary.csv`.
- `branchwise_cutoff_convergence_v3_3.py` — independent Fock-space cutoff audit for every displayed branch.
- `arbitrary_jacobi_control_v3_3.py` — independent six-level real Jacobi-chain control for Theorem 1.
- `verify_release.py` — checks the reference numerical outputs against the v3.3 release tolerances.
- `data/` — reference CSV/text outputs used for the manuscript release.
- `figures/` — reference Figure 1 in PDF and PNG formats.
- `requirements.txt` — pinned numerical environment used for the release run.
- `LICENSE` — MIT License.

## Reference environment

- Python 3.13.5
- NumPy 2.3.5
- SciPy 1.17.0
- Matplotlib 3.10.8

Install the pinned environment with:

```bash
python -m pip install -r requirements.txt
```

## Reproduce the calculations

Run from the repository root:

```bash
python projective_reconstruction_hierarchy_v3_3.py
python branchwise_cutoff_convergence_v3_3.py
python arbitrary_jacobi_control_v3_3.py
```

The scripts require no network access and no external dataset. Generated files are written to the local `output/` directory.

To check the release reference files directly:

```bash
python verify_release.py
```

## v3.3 reference values

The reference `data/Fit_summary.csv` reproduces the numerical hierarchy used in the manuscript:

- U-only final occupation: `9.66209201163585`
- U+W final occupation: `5.39569650290132`
- U+W+Z final occupation: `3.52961978385058`
- exact final occupation: `3.52961978384978`

The full reconstruction agrees with the exact final occupation to numerical precision. The manuscript reports robust rounded bounds rather than solver-run-specific last digits for the deepest reconstruction.

The branchwise cutoff audit gives a maximum trajectory difference below `1e-12` for every displayed branch. The independent Jacobi control reconstructs all tested quantities with maximum absolute error below `1e-15` in the release environment.

## Numerical implementation notes

The short-window fits use DOP853 with `rtol=1e-13` and `atol=1e-15`. For the full-depth fit, projective-coordinate residual blocks are scaled internally to avoid premature termination from the much smaller deepest coordinate; reported residuals are evaluated on the unscaled physical residuals.

Forward occupations for the stiffer regularized branches are propagated in an exactly equivalent diagonal interaction picture. This phase transformation leaves occupations invariant while reducing artificial stiffness at larger Fock cutoffs. The U-only branch is audited directly in the Schrödinger picture.

## License

Code is released under the MIT License. Numerical data in this archive are generated from the equations and parameters stated in the manuscript and may be reused with appropriate citation of the associated work.
