import numpy as np, math
np.set_printoptions(precision=12,suppress=True)
# Deterministic non-polynomial-in-level Jacobi chain, hbar=1.
N=6
E0=np.array([0.12, 0.37, 1.91, 0.82, 3.44, 1.27],float)
Edot=np.array([0.07,-0.13,0.05,0.19,-0.11,0.03],float)
Edd=np.array([0.02,-0.01,0.04,-0.03,0.01,0.05],float)
g0=np.array([0.73,1.11,0.58,0.94,0.67],float)
gdot=np.array([-0.19,0.08,0.14,-0.05,0.09],float)
gdd=np.array([0.06,-0.02,0.03,0.04,-0.01],float)

def Hcoeff(k):
    H=np.zeros((N,N),complex)
    if k==0:
        d=E0; off=g0
    elif k==1:
        d=Edot; off=gdot
    elif k==2:
        d=0.5*Edd; off=0.5*gdd
    else:
        d=np.zeros(N); off=np.zeros(N-1)
    H[np.arange(N),np.arange(N)]=d
    for j,x in enumerate(off):
        H[j,j+1]=H[j+1,j]=x
    return H

# Taylor coefficients psi_m in psi(t)=sum psi_m t^m.
maxm=N+1
psi=[np.zeros(N,complex) for _ in range(maxm+1)]
psi[0][0]=1.0
for m in range(maxm):
    rhs=np.zeros(N,complex)
    for k in range(m+1):
        rhs += Hcoeff(k) @ psi[m-k]
    psi[m+1]=(-1j/(m+1))*rhs

# Series division z_n=c_n/c_0.
c0=np.array([psi[m][0] for m in range(maxm+1)],complex)
zcoeff=np.zeros((N,maxm+1),complex)
for n in range(N):
    c=np.array([psi[m][n] for m in range(maxm+1)],complex)
    z=np.zeros(maxm+1,complex)
    for m in range(maxm+1):
        acc=c[m]
        for k in range(1,m+1):
            acc -= c0[k]*z[m-k]
        z[m]=acc/c0[0]
    zcoeff[n]=z

A=[1+0j]
R=[0+0j]
for n in range(1,N):
    zn=zcoeff[n]
    a=math.factorial(n)*zn[n]
    r=(n+1)*zn[n+1]/zn[n]
    A.append(a); R.append(r)

print('n E-E0 reconstructed g reconstructed gdot/g reconstructed')
maxerr=0
rows=[]
for n in range(1,N):
    dg=R[n]-R[n-1]
    Erec=-dg.imag
    grec=abs(A[n]/A[n-1])
    logr=dg.real/n
    trueE=E0[n]-E0[0]
    trueg=g0[n-1]
    truelog=gdot[n-1]/g0[n-1]
    errs=[abs(Erec-trueE),abs(grec-trueg),abs(logr-truelog)]
    maxerr=max(maxerr,*errs)
    rows.append((n,trueE,Erec,trueg,grec,truelog,logr))
    print(n,trueE,Erec,trueg,grec,truelog,logr)
print('MAX_ABS_ERROR',maxerr)
