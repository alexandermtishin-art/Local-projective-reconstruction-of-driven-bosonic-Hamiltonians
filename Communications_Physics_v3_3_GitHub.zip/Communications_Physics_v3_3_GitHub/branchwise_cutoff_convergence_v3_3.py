#!/usr/bin/env python3
"""Independent branchwise Fock-cutoff convergence audit for v3.3.

The U-only branch is cheap in the Schrödinger picture and is audited directly.
The stiffer U+W / U+W+Z branches use an exactly equivalent diagonal interaction
picture, which leaves occupations invariant. The audit uses tighter solver
 tolerances (rtol=1e-13, atol=1e-15) to isolate basis-truncation error.
"""
from pathlib import Path
import csv, math
import numpy as np
from scipy.integrate import solve_ivp

OUT = Path(__file__).resolve().parent / "output"
OUT.mkdir(exist_ok=True)
TS = np.linspace(0.0, 1.2, 401)


def Omega(t): return 1.0 + 0.4*t + 0.1*t*t
def Sint(t): return t + 0.2*t*t + (0.1/3.0)*t**3
def lam(t): return 3.0 + 0.2*t

def arrays(M, p):
    ns=2*np.arange(M,dtype=float)
    fs=[]
    for k in (2,4,6):
        a=np.ones(M)
        for j in range(k): a*=np.maximum(ns-j,0.0)
        fs.append(a)
    U,W,Z=p
    d=ns+U*fs[0]/2+W*fs[1]/24+Z*fs[2]/720
    off=np.sqrt((ns[:-1]+1)*(ns[:-1]+2))
    return ns,d,off

def occ_direct(p,M):
    ns,d,off=arrays(M,p); y0=np.zeros(M,complex);y0[0]=1
    def rhs(t,y):
        Om=Omega(t); c=lam(t)*Om/4*off
        dy=-1j*(Om*d)*y
        dy[:-1]+=-1j*c*y[1:]; dy[1:]+=-1j*c*y[:-1]
        return dy
    s=solve_ivp(rhs,(0,1.2),y0,t_eval=TS,rtol=1e-13,atol=1e-15,method='DOP853')
    return np.sum(abs(s.y.T)**2*ns,axis=1)

def occ_ip(p,M):
    ns,d,off=arrays(M,p); dd=d[:-1]-d[1:]; y0=np.zeros(M,complex);y0[0]=1
    def rhs(t,y):
        phase=np.exp(1j*dd*Sint(t)); c=lam(t)*Omega(t)/4*off
        dy=np.zeros_like(y)
        dy[:-1]+=-1j*c*phase*y[1:]; dy[1:]+=-1j*c*np.conj(phase)*y[:-1]
        return dy
    s=solve_ivp(rhs,(0,1.2),y0,t_eval=TS,rtol=1e-13,atol=1e-15,method='DOP853')
    return np.sum(abs(s.y.T)**2*ns,axis=1)

def main():
    # Parameters are read from the reference v3.3 fit output to the precision
    # needed for the convergence test; exact branch is included separately.
    branches=[
      ('U_only', np.array([0.04999614452900248,0,0]),40,44,'direct'),
      ('U_W', np.array([0.0499999897736048,0.00993684499047393,0]),16,20,'ip'),
      ('U_W_Z', np.array([0.05,0.01,0.1]),16,20,'ip'),
      ('exact', np.array([0.05,0.01,0.1]),16,20,'ip'),
    ]
    rows=[]
    for name,p,m1,m2,mode in branches:
        fn=occ_direct if mode=='direct' else occ_ip
        a,b=fn(p,m1),fn(p,m2)
        rows.append((name,m1,m2,float(np.max(abs(a-b))),float(abs(a[-1]-b[-1])),mode))
    with open(OUT/'branchwise_cutoff_convergence.csv','w',newline='') as f:
        w=csv.writer(f);w.writerow(['branch','reported_cutoff','audit_cutoff','max_trajectory_difference','final_value_difference','representation'])
        w.writerows(rows)
    for r in rows: print(r)

if __name__=='__main__': main()
