#!/usr/bin/env python3
"""Reproduce Fig. 1, Table 1, and branchwise cutoff convergence for v3.3.

Local projective reconstruction of driven bosonic Hamiltonians
A. M. Tishin

No external data or network access is required.
"""
from pathlib import Path
import csv, math
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

OUT = Path(__file__).resolve().parent / "output"
OUT.mkdir(exist_ok=True)

TRUE = np.array([0.05, 0.01, 0.10], dtype=float)
FIT_STATES = 16
FORWARD_CUTOFF = {1: 40, 2: 16, 3: 16, "exact": 16}
CONV_CUTOFF = {1: 44, 2: 20, 3: 20, "exact": 20}


def Omega(t):
    return 1.0 + 0.4*t + 0.1*t*t


def lam(t):
    # Independently prescribed dimensionless pair-drive amplitude lambda = 4 G / Omega.
    return 3.0 + 0.2*t


def basis_arrays(M):
    ns = 2*np.arange(M, dtype=float)
    f = []
    for k in (2, 4, 6):
        a = np.ones(M, dtype=float)
        for j in range(k):
            a *= np.maximum(ns-j, 0.0)
        f.append(a)
    off = np.sqrt((ns[:-1]+1.0)*(ns[:-1]+2.0))
    return ns, f[0], f[1], f[2], off


def trajectory(pars, ts, M, rtol, atol):
    ns, f2, f4, f6, off = basis_arrays(M)
    U, W, Z = np.asarray(pars, dtype=float)
    y0 = np.zeros(M, dtype=complex)
    y0[0] = 1.0

    def rhs(t, y):
        Om = Omega(t)
        G = lam(t)*Om/4.0
        diag = Om*(ns + U*f2/2.0 + W*f4/math.factorial(4) + Z*f6/math.factorial(6))
        dy = -1j*diag*y
        c = G*off
        dy[:-1] += -1j*c*y[1:]
        dy[1:] += -1j*c*y[:-1]
        return dy

    sol = solve_ivp(rhs, (0.0, float(np.max(ts))), y0, t_eval=np.asarray(ts),
                    rtol=rtol, atol=atol, method="DOP853")
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y.T, ns


def occupation(pars, ts, M, rtol=1e-11, atol=1e-13):
    """Occupation propagation in an exactly equivalent diagonal interaction picture.

    Removing the analytically integrable diagonal phase avoids artificial stiffness at
    large Fock cutoffs. Occupations are invariant under this diagonal phase rotation.
    """
    ns, f2, f4, f6, off = basis_arrays(M)
    U, W, Z = np.asarray(pars, dtype=float)
    d = ns + U*f2/2.0 + W*f4/math.factorial(4) + Z*f6/math.factorial(6)
    dd = d[:-1] - d[1:]
    y0 = np.zeros(M, dtype=complex)
    y0[0] = 1.0

    def Sint(t):
        return t + 0.2*t*t + (0.1/3.0)*t**3

    def rhs(t, y):
        G = lam(t)*Omega(t)/4.0
        phase = np.exp(1j*dd*Sint(t))
        c = G*off
        dy = np.zeros_like(y)
        dy[:-1] += -1j*c*phase*y[1:]
        dy[1:] += -1j*c*np.conj(phase)*y[:-1]
        return dy

    sol = solve_ivp(rhs, (0.0, float(np.max(ts))), y0, t_eval=np.asarray(ts),
                    rtol=rtol, atol=atol, method="DOP853")
    if not sol.success:
        raise RuntimeError(sol.message)
    Y = sol.y.T
    return np.sum(np.abs(Y)**2 * ns, axis=1)


def fit_nested_models():
    ts_fit = np.linspace(0.003, 0.03, 15)
    Yobs, _ = trajectory(TRUE, ts_fit, FIT_STATES, 1e-13, 1e-15)
    fits = []

    for order in (1, 2, 3):
        zobs = Yobs[:, 1:1+order] / Yobs[:, [0]]
        # The deepest coordinate is much smaller on the short window. For the
        # full-depth fit only, scale coordinate blocks to avoid premature
        # termination from poor numerical conditioning. Reported RMS values
        # below are always computed from the unscaled physical residuals.
        coord_scale = np.ones(order)
        if order == 3:
            coord_scale = np.maximum(np.max(np.abs(zobs), axis=0), 1e-14)

        def raw_residual(p):
            pars = np.zeros(3)
            pars[:order] = p
            Y, _ = trajectory(pars, ts_fit, FIT_STATES, 1e-13, 1e-15)
            z = Y[:, 1:1+order] / Y[:, [0]]
            return z-zobs

        def objective(p):
            d = raw_residual(p) / coord_scale[None, :]
            d = d.ravel()
            return np.r_[d.real, d.imag]

        x0 = np.array([0.04, 0.005, 0.05])[:order]
        res = least_squares(objective, x0, xtol=1e-14, ftol=1e-14, gtol=1e-14,
                            max_nfev=120, x_scale="jac")
        pars = np.zeros(3)
        pars[:order] = res.x
        raw = raw_residual(res.x).ravel()
        raw_vec = np.r_[raw.real, raw.imag]
        rnorm = float(np.linalg.norm(raw_vec))
        rms = rnorm / np.sqrt(2*len(ts_fit)*order)
        fits.append({"order": order, "pars": pars,
                     "residual_norm": rnorm,
                     "fit_rms_residual": float(rms)})
    return fits


def main():
    fits = fit_nested_models()
    ts = np.linspace(0.0, 1.2, 401)
    ntrue = occupation(TRUE, ts, FORWARD_CUTOFF["exact"])

    rows = []
    curves = []
    for f in fits:
        order = f["order"]
        n = occupation(f["pars"], ts, FORWARD_CUTOFF[order])
        rel_final = float(abs(n[-1]-ntrue[-1])/ntrue[-1])
        rms_rel = float(np.sqrt(np.mean((n-ntrue)**2))/np.sqrt(np.mean(ntrue**2)))
        row = dict(f)
        row.update(final_occupation=float(n[-1]), relative_final_error=rel_final,
                   rms_relative_error=rms_rel)
        rows.append(row)
        curves.append(n)

    # Branchwise cutoff convergence is performed by the separate
    # branchwise_cutoff_convergence_v3_3.py audit script.

    # Data used by Figure 1.
    with open(OUT/"Figure_1_data.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["time", "exact_U_W_Z", "fit_U_only", "fit_U_W", "fit_U_W_Z"])
        for i, t in enumerate(ts):
            w.writerow([f"{t:.12g}", f"{ntrue[i]:.15g}",
                        f"{curves[0][i]:.15g}", f"{curves[1][i]:.15g}", f"{curves[2][i]:.15g}"])

    with open(OUT/"Fit_summary.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["depth", "U", "W", "Z", "residual_norm", "fit_rms_residual",
                    "final_occupation", "relative_final_error", "rms_relative_error"])
        for r in rows:
            w.writerow([r["order"], *[f"{x:.15g}" for x in r["pars"]],
                        f"{r['residual_norm']:.15g}", f"{r['fit_rms_residual']:.15g}",
                        f"{r['final_occupation']:.15g}", f"{r['relative_final_error']:.15g}",
                        f"{r['rms_relative_error']:.15g}"])
        w.writerow(["exact", *[f"{x:.15g}" for x in TRUE], "", "",
                    f"{ntrue[-1]:.15g}", "", ""])


    # Accessible monochrome figure: no color-only encoding.
    fig, ax = plt.subplots(figsize=(7.0, 4.5), dpi=300)
    ax.plot(ts, ntrue, linewidth=2.4, linestyle="-", color="black", label="Exact U+W+Z")
    styles = [("--", "o", "0.30"), ("-.", "s", "0.48"), (":", "^", "0.62")]
    labels = [r"Reconstruction from $\zeta_2$: U",
              r"Reconstruction from $\zeta_2,\zeta_4$: U+W",
              r"Reconstruction from $\zeta_2,\zeta_4,\zeta_6$: U+W+Z"]
    for n, (ls, mk, grey), label in zip(curves, styles, labels):
        ax.plot(ts, n, linestyle=ls, linewidth=1.8, marker=mk, markevery=44,
                markersize=3.2, color=grey, label=label)
    ax.axvline(0.03, linestyle=(0, (2, 2)), linewidth=1.1, color="0.2")
    ax.set_xlabel("Dimensionless time")
    ax.set_ylabel(r"$\langle \hat n \rangle$")
    ax.set_xlim(0.0, 1.2)
    ax.legend(frameon=False, fontsize=8.0, loc="upper left", handlelength=3.1)
    fig.tight_layout()
    for ext in ("png", "pdf", "svg"):
        fig.savefig(OUT/f"Figure_1_hierarchical_prediction_v3_3.{ext}",
                    dpi=600 if ext == "png" else None, bbox_inches="tight")
    plt.close(fig)

    print("Nested fit / forward prediction")
    for r in rows:
        print(r)
    print("EXACT_FINAL", ntrue[-1])


if __name__ == "__main__":
    main()
