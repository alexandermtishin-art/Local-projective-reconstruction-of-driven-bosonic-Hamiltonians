#!/usr/bin/env python3
from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


def read_csv(name):
    with open(DATA / name, newline="") as f:
        return list(csv.DictReader(f))

fit = read_csv("Fit_summary.csv")
rows = {r["depth"]: r for r in fit}
expected = {
    "1": 9.66209201163585,
    "2": 5.39569650290132,
    "3": 3.52961978385058,
    "exact": 3.52961978384978,
}
for key, val in expected.items():
    got = float(rows[key]["final_occupation"])
    if abs(got - val) > 5e-12:
        raise SystemExit(f"FAIL final occupation depth={key}: got {got}, expected {val}")

conv = read_csv("branchwise_cutoff_convergence.csv")
max_diff = max(float(r["max_trajectory_difference"]) for r in conv)
if max_diff >= 1e-12:
    raise SystemExit(f"FAIL cutoff convergence: max trajectory difference {max_diff}")

text = (DATA / "arbitrary_jacobi_control_output_v3_3.txt").read_text()
marker = "MAX_ABS_ERROR"
vals = [line.split()[-1] for line in text.splitlines() if line.startswith(marker)]
if not vals:
    raise SystemExit("FAIL Jacobi control: MAX_ABS_ERROR not found")
jacobi = float(vals[-1])
if jacobi >= 1e-15:
    raise SystemExit(f"FAIL Jacobi control: max abs error {jacobi}")

print("PASS v3.3 reference verification")
print(f"max cutoff trajectory difference = {max_diff:.3e}")
print(f"Jacobi max abs error = {jacobi:.3e}")
